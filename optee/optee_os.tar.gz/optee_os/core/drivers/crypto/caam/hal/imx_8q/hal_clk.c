// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright 2020-2021 NXP
 */
#include <caam_hal_clk.h>
#include <compiler.h>

void caam_hal_clk_enable(bool enable __unused)
{
}
