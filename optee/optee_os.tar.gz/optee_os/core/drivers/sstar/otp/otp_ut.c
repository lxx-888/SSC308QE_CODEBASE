/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <kernel/thread.h>
#include <sm/optee_smc.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <mm/core_memprot.h>
#include <hal_tzsp.h>
#include <string.h>
#include "drvOTP.h"
#include "otp_ut.h"


static void tz_otpctrl(struct thread_smc_args *args)
{
    otp_config otp_cmd;

    memset(&otp_cmd, 0, sizeof(otp_cmd));
    otp_cmd.base_addr = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    otp_cmd.buf = (core_mmu_get_va(OTP_DEBUG_SRAM_ADDR, MEM_AREA_RAM_SEC, 1));
    otp_cmd.op = args->a2;
    otp_cmd.cmd = args->a3;
    otp_cmd.val = args->a4;

    OTP_main(&otp_cmd);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

void otp_ut(struct thread_smc_args *args)
{
    switch (args->a1) {

    case CMD_OTP_CTRL:
        tz_otpctrl(args);
        break;

    default:
        args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
        break;
    }
}


TEE_Result otp_read_ut_pta(uint32_t nParamTypes, TEE_Param pParams[TEE_NUM_PARAMS])
{
    otp_config otp_cmd;

    memset(&otp_cmd, 0, sizeof(otp_cmd));
    if (nParamTypes != TEE_PARAM_TYPES(TEE_PARAM_TYPE_VALUE_INPUT,
                         TEE_PARAM_TYPE_MEMREF_INOUT,
                         TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE))
                         return TEE_ERROR_BAD_PARAMETERS;

    otp_cmd.base_addr = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    otp_cmd.op = OTP_R;
    otp_cmd.cmd = pParams[0].value.a;
    otp_cmd.val = 0;
    otp_cmd.buf = (unsigned long)pParams[1].memref.buffer;
    otp_cmd.bufsize = pParams[1].memref.size;

    EMSG("[optee] op = 0x%lx  cmd=0x%lx  val=0x%lx", otp_cmd.op, otp_cmd.cmd, otp_cmd.val);

    OTP_main(&otp_cmd);

    return TEE_SUCCESS;
}

TEE_Result otp_write_ut_pta(uint32_t nParamTypes, TEE_Param pParams[TEE_NUM_PARAMS])
{
    otp_config otp_cmd;

    memset(&otp_cmd, 0, sizeof(otp_cmd));
    if (nParamTypes != TEE_PARAM_TYPES(TEE_PARAM_TYPE_VALUE_INPUT,
                         TEE_PARAM_TYPE_VALUE_INPUT,
                         TEE_PARAM_TYPE_MEMREF_INOUT,
                         TEE_PARAM_TYPE_NONE))
                         return TEE_ERROR_BAD_PARAMETERS;

    otp_cmd.op = OTP_W;
    otp_cmd.cmd = pParams[0].value.a;
    otp_cmd.val = pParams[1].value.a;
    otp_cmd.buf = (unsigned long)pParams[2].memref.buffer;
    otp_cmd.bufsize = pParams[2].memref.size;

    EMSG("[optee] op = 0x%lx  cmd=0x%lx  val=0x%lx", otp_cmd.op, otp_cmd.cmd, otp_cmd.val);

    OTP_main(&otp_cmd);

    return TEE_SUCCESS;
}


