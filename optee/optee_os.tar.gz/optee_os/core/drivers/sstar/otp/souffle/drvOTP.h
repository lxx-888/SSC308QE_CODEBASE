/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef DRVOTP_H
#define DRVOTP_H

/* operation*/
#define OTP_W 0x1
#define OTP_R 0x2

typedef struct
{
    unsigned long  op;      /* Write: 0x1, Read: 0x2 */
    unsigned long  cmd;     /* OTP Command */
    unsigned long  val;     /* OTP write val */
    uint8_t*  buf;     /* if set buf, msg will store here*/
    uint16_t  bufsize; /* buf size */
} OTP_OP_CMD_t;

void OTP_main(OTP_OP_CMD_t* otp_op);

#endif

