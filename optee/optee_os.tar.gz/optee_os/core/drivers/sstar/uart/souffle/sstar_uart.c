/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.

This software contains core/drivers/serial8250_uart.c
(https://github.com/OP-TEE/optee_os/blob/master/core/drivers/serial8250_uart.c)
under BSD 2-clause.
For the licensing rule and related notices of core/drivers/serial8250_uart.c,
please see the Licenses.txt file.
*/

#include <compiler.h>
#include <console.h>
#include <sstar_uart.h>
#include <io.h>
#include <keep.h>
#include <util.h>
#include <kernel/dt.h>

/* uart register defines */
#define UART_RHR	0x00*2
#define UART_THR	0x00*2
#define UART_IER	0x04*2
#define UART_ISR	0x08*2
#define UART_FCR	0x08*2
#define UART_LCR	0x0C*2
#define UART_MCR	0x10*2
#define UART_LSR	0x14*2
#define UART_MSR	0x18*2
#define UART_USR	0x1C*2

/* uart status register bits */
#define LSR_TEMT	0x40 /* Transmitter empty */
#define LSR_THRE	0x20 /* Transmit-hold-register empty */
#define LSR_EMPTY	(LSR_TEMT | LSR_THRE)
#define LSR_DR		0x01 /* DATA Ready */

#define USR_BUSY            0x01
#define USR_TXFIFO_NOT_FULL 0x02
#define USR_TXFIFO_EMPTY    0x04

static vaddr_t chip_to_base(struct serial_chip *chip)
{
	struct sstar_uart_data *pd =
		container_of(chip, struct sstar_uart_data, chip);

	return io_pa_or_va(&pd->base, SSTAR_UART_REG_SIZE);
}

static void sstar_uart_flush(struct serial_chip *chip)
{
	vaddr_t base = chip_to_base(chip);

	while (1) {
		uint32_t state = io_read32(base + UART_USR);

		/* Wait until transmit FIFO is empty */
		if ((state & USR_TXFIFO_NOT_FULL) == USR_TXFIFO_NOT_FULL)
			break;
	}
}

static bool sstar_uart_have_rx_data(struct serial_chip *chip)
{
	vaddr_t base = chip_to_base(chip);

	return (io_read32(base + UART_LSR) & LSR_DR);
}

static int sstar_uart_getchar(struct serial_chip *chip)
{
	vaddr_t base = chip_to_base(chip);

	while (!sstar_uart_have_rx_data(chip)) {
		/* Transmit FIFO is empty, waiting again */
		;
	}
	return io_read32(base + UART_RHR) & 0xff;
}

static void sstar_uart_putc(struct serial_chip *chip, int ch)
{
	vaddr_t base = chip_to_base(chip);

	sstar_uart_flush(chip);

	/* Write out character to transmit FIFO */
	io_write32(base + UART_THR, ch);
}

static const struct serial_ops sstar_uart_ops = {
	.flush = sstar_uart_flush,
	.getchar = sstar_uart_getchar,
	.have_rx_data = sstar_uart_have_rx_data,
	.putc = sstar_uart_putc,
};
DECLARE_KEEP_PAGER(sstar_uart_ops);

void sstar_uart_init(struct sstar_uart_data *pd, paddr_t base,
			  uint32_t __unused uart_clk,
			  uint32_t __unused baud_rate)

{
	pd->base.pa = base;
	pd->chip.ops = &sstar_uart_ops;

	/*
	 * do nothing, debug uart(uart0) share with normal world,
	 * everything for uart0 is ready now.
	 */
}

#if 0
#ifdef CFG_DT

static struct serial_chip *sstar_uart_dev_alloc(void)
{
	struct sstar_uart_data *pd = calloc(1, sizeof(*pd));

	if (!pd)
		return NULL;
	return &pd->chip;
}

static int sstar_uart_dev_init(struct serial_chip *chip,
			       const void *fdt,
			       int offs,
			       const char *parms)
{
	struct sstar_uart_data *pd =
		container_of(chip, struct sstar_uart_data, chip);
	vaddr_t vbase;
	paddr_t pbase;
	size_t size;

	if (parms && parms[0])
		IMSG("serial8250_uart: device parameters ignored (%s)", parms);

	if (dt_map_dev(fdt, offs, &vbase, &size) < 0)
		return -1;

	if (size < SSTAR_UART_REG_SIZE) {
		EMSG("sstar_uart: register size too small: %zx", size);
		return -1;
	}

	pbase = virt_to_phys((void *)vbase);
	sstar_uart_init(pd, pbase, 0, 0);

	return 0;
}

static void sstar_uart_dev_free(struct serial_chip *chip)
{
	struct sstar_uart_data *pd =
	  container_of(chip,  struct sstar_uart_data, chip);

	free(pd);
}

static const struct serial_driver sstar_driver = {
	.dev_alloc = sstar_uart_dev_alloc,
	.dev_init = sstar_uart_dev_init,
	.dev_free = sstar_uart_dev_free,
};

static const struct dt_device_match sstar_match_table[] = {
	{ .compatible = "snps,dw-apb-uart" },
	{ 0 }
};

const struct dt_driver sstar_dt_driver __dt_driver = {
	.name = "sstar_uart",
	.match_table = sstar_match_table,
	.driver = &sstar_driver,
};

#endif /* CFG_DT */
#endif
