/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.

This software contains core/drivers/serial8250_uart.h
(https://github.com/OP-TEE/optee_os/blob/master/core/include/drivers/serial8250_uart.h)
under BSD 2-clause.
For the licensing rule and related notices of core/drivers/serial8250_uart.h,
please see the Licenses.txt file.
*/

#ifndef SSTAR_UART_H
#define SSTAR_UART_H

#include <types_ext.h>
#include <drivers/serial.h>

#define SSTAR_UART_REG_SIZE 0x0800

struct sstar_uart_data {
	struct io_pa_va base;
	struct serial_chip chip;
};

void sstar_uart_init(struct sstar_uart_data *pd, paddr_t base,
			  uint32_t uart_clk, uint32_t baud_rate);

#endif /* SSTAR_UART_H */

