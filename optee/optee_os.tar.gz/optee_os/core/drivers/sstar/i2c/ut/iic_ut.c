/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <tee_api_types.h>
#include <kernel/delay.h>
#include <iic_ut.h>

#define BUF_DATA_LENGTH 32

s32 i2c_ut(u8 i2c_bus)
{
    s32    i   = 0;
    s32    ret = 0;
    struct i2c_handler_t *handle;
    struct i2c_msg msg_w[1];
    struct i2c_msg msg_r[2];
    unsigned char *in_buf;
    unsigned char *out_buf;

    handle = sstar_i2c_get_handler(i2c_bus);
    if (0 == handle->bus_init)
    {
        EMSG("get i2c handle err\n");
        return -1;
    }

    in_buf  = (unsigned char *)malloc(BUF_DATA_LENGTH);
    out_buf = (unsigned char *)malloc(BUF_DATA_LENGTH + 2);

    out_buf[0] = 0x00;
    out_buf[1] = 0x00;
    for (i = 0; i < BUF_DATA_LENGTH; i++)
    {
        out_buf[i + 2] = i + 1;
    }

    //write
    msg_w[0].addr   = 0x50;
    msg_w[0].flags  = 0;
    msg_w[0].len    = BUF_DATA_LENGTH + 2;
    msg_w[0].buf    = out_buf;
    ret = sstar_i2c_master_xfer(handle, msg_w, 1);
    if (1 != ret)
    {
        free(in_buf);
        free(out_buf);
        EMSG("i2c ut: write fail\n");
        return -1;
    }

    udelay(10000);

    //read
    msg_r[0].addr   = 0x50;
    msg_r[0].flags  = 0;
    msg_r[0].len    = 2;
    msg_r[0].buf    = out_buf;

    msg_r[1].addr     = 0x50;
    msg_r[1].flags    = MIIC_MSG_RD;
    msg_r[1].len      = BUF_DATA_LENGTH;
    msg_r[1].buf      = in_buf;
    ret = sstar_i2c_master_xfer(handle, msg_r, 2);
    if (2 != ret)
    {
        free(in_buf);
        free(out_buf);
        EMSG("i2c ut: read fail\n");
        return -1;
    }

    //compare
    for (i = 0; i < BUF_DATA_LENGTH; i++)
    {
        if (out_buf[i + 2] - in_buf[i])
        {
            EMSG("checkout index %d error\n", i);
            return -1;
        }
    }

    EMSG("i2c check pass\n");
    free(in_buf);
    free(out_buf);
    return 0;
}

TEE_Result i2c_ut_pta(u32 para_types, TEE_Param paras[TEE_NUM_PARAMS])

{

    (void)paras;

    if (para_types != TEE_PARAM_TYPES(TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE))
    {
        return TEE_ERROR_BAD_PARAMETERS;
    }

    i2c_ut(2);

    return TEE_SUCCESS;

}


