/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _DRV_IIC_H_
#define _DRV_IIC_H_

#include <sstar_types.h>
#include <sstar_platform.h>

struct i2c_msg {
    u16 addr;                          /* slave address */
    u16 flags;

#define MIIC_MSG_RD            0x0001  /* read data, from slave to master */
                                       /* MIIC_MSG_RD is guaranteed to be 0x0001! */
#define MIIC_MSG_TEN           0x0010  /* this is a ten bit chip address */
#define MIIC_MSG_DMA_SAFE      0x0200  /* the buffer of this message is DMA safe */
                                       /* makes only sense in kernelspace */
                                       /* userspace buffers are copied anyway */
#define MIIC_MSG_RECV_LEN      0x0400  /* length will be first received byte */
#define MIIC_MSG_NO_RD_ACK     0x0800  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define MIIC_MSG_IGNORE_NAK    0x1000  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define MIIC_MSG_REV_DIR_ADDR  0x2000  /* if I2C_FUNC_PROTOCOL_MANGLING */
#define MIIC_MSG_NOSTART       0x4000  /* if I2C_FUNC_NOSTART */
#define MIIC_MSG_STOP          0x8000  /* if I2C_FUNC_PROTOCOL_MANGLING */
    u16 len;                           /* msg lengt*/
    u8 *buf;                           /* pointer to msg data*/
};

struct i2c_handler_t{
    u8    bus_init;
    u8    bus_num;
    void *priv;  // store i2c_control pointer

};

typedef s32 (*sstar_i2c_async_calbck)(char para_msg_done, void *reserved);
extern s32 sstar_i2c_init(struct i2c_handler_t *i2c_handle);
extern struct i2c_handler_t *sstar_i2c_get_handler(u8 port);
extern s32 sstar_i2c_master_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num);
extern s32 sstar_i2c_master_async_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num);
extern s32 sstar_i2c_async_cb_set(struct i2c_handler_t *i2c_handle, sstar_i2c_async_calbck para_cb, void *reserved);
extern s32 sstar_i2c_wnwrite_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num,
                                  u8 para_wnlen, u16 para_waitcnt);
extern s32 sstar_i2c_wnwrite_async_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num,
                                        u8 para_wnlen, u16 para_waitcnt);

#endif
