/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef __IIC_OS__
#define __IIC_OS__

#include <string.h>
#include <registers.h>
#include <kernel/delay.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <tee/cache.h>

#ifdef CONFIG_ARM64
#define HAL_I2C_READ_WORD(_reg)        (*(volatile u16 *)(u64)(_reg))
#define HAL_I2C_WRITE_WORD(_reg, _val) ((*(volatile u16 *)(u64)(_reg)) = (u16)(_val))
#define HAL_I2C_WRITE_WORD_MASK(_reg, _val, _mask) \
    ((*(volatile u16 *)(u64)(_reg)) = ((*(volatile u16 *)(u64)(_reg)) & ~(_mask)) | ((u16)(_val) & (_mask)))

#define HAL_I2C_WRITE_BYTE(_reg, _val) ((*(volatile unsigned char *)((u64)_reg)) = (u8)(_val))
#define HAL_I2C_READ_BYTE(_reg)        (*(volatile unsigned char *)((u64)_reg))
#else
#define HAL_I2C_READ_WORD(_reg)        (*(volatile u16 *)(u32)(_reg))
#define HAL_I2C_WRITE_WORD(_reg, _val) ((*(volatile u16 *)(u32)(_reg)) = (u16)(_val))
#define HAL_I2C_WRITE_WORD_MASK(_reg, _val, _mask) \
    ((*(volatile u16 *)(u32)(_reg)) = ((*(volatile u16 *)(u32)(_reg)) & ~(_mask)) | ((u16)(_val) & (_mask)))

#define HAL_I2C_WRITE_BYTE(_reg, _val) ((*(volatile unsigned char *)((u32)_reg)) = (u8)(_val))
#define HAL_I2C_READ_BYTE(_reg)        (*(volatile unsigned char *)((u32)_reg))
#endif

#define CONFIG_SSTAR_PM_DMA          0
#define HAL_I2C_PM_RAM_ACCESS_VAL    0x1
#define HAL_I2C_PM_RAM_ACCESS_MASK   0x3
#define HAL_I2C_PM_RAM_ACCESS_BANK   0x1E
#define HAL_I2C_PM_RAM_ACCESS_OFFSET 0x5E

#define MIU_BASE_OFFSET 0x20000000

#define I2C_DELAY_N_US(_x) \
    do                     \
    {                      \
        udelay(_x);  \
    } while (0)

#define dmsg_i2c_halerr(fmt, ...)           \
    do                                      \
    {                                       \
        EMSG("err: " fmt, ##__VA_ARGS__); \
    } while (0)

//#define HAL_I2C_DMSG_ENABLE
#ifdef HAL_I2C_DMSG_ENABLE
#define dmsg_i2c_halwarn(fmt, ...)           \
    do                                       \
    {                                        \
        DMSG("debug " fmt, ##__VA_ARGS__); \
    } while (0)
#else
#define dmsg_i2c_halwarn(fmt, ...)
#endif

#define hal_i2c_cache_flush(_ptr_, _size_)        cache_operation(TEE_CACHEFLUSH, (void *)_ptr_, _size_)
#define hal_i2c_cache_invalidate(_ptr_, _size_)   cache_operation(TEE_CACHEINVALIDATE, (void *)_ptr_, _size_)

#endif
