/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HAL_IIC_CFG_H_
#define _HAL_IIC_CFG_H_

#include <irqs.h>
#include <iic_os.h>

#define HAL_I2C_SRCLK_12M (0x8)
#define HAL_I2C_SRCLK_54M (0x4)
#define HAL_I2C_SRCLK_72M (0x0)

#define I2C_INIT_SPEED 200000
#define I2C_MAX_SRCCLK 72000000

struct clk_info
{
    u32 rate;
    u16 value;
};

struct reg_t{
    u64 bank_base;
    u8  reg_offset;
    u8  bit_shift;
    u32 bit_mask;
};

struct i2c_reg_t{
    u32              clk_num;
    struct clk_info *src_clk;
    struct reg_t     reg_clkgen;
    struct reg_t     reg_padmod;
};

struct hal_i2c_config{
    u32  dma;
    u32  rate;
    u32  group;
    u32  io_reg;
    u32  irq_num;
    u32  t_su_sta;
    u32  t_hd_sta;
    u32  t_su_sto;
    u32  t_hd_sto;
    u32  output_mode;
    u16  padmod;
    struct i2c_reg_t *pst_reg;
};

static struct clk_info i2c_src_clk[] = {{72000000, (0 << 2)},
                                        {54000000, (1 << 2)},
                                        {12000000, (2 << 2)}};

#define HAL_I2C_SRC_CLK_SIZE (sizeof(i2c_src_clk)/sizeof(struct clk_info))

struct i2c_reg_t i2c2_reg =
{
    .clk_num = HAL_I2C_SRC_CLK_SIZE,

    .src_clk = i2c_src_clk,

    .reg_clkgen = {
        .bank_base  = 0x207000,
        .reg_offset = 0x37,
        .bit_shift  = 12,
        .bit_mask   = (BIT15 | BIT14 | BIT13 | BIT12)
    },

    .reg_padmod = {
        .bank_base  = 0x23FC00,
        .reg_offset = 0x10,
        .bit_shift  = 4,
        .bit_mask   = (BIT5 | BIT4)
    },
};

const struct hal_i2c_config hal_i2c_cfg_hdl[] = {

    // i2c-2
    {
        .dma         = 1,
        .rate        = I2C_INIT_SPEED,
        .group       = 2,
        .io_reg      = 0x222C00,
        .irq_num     = INT_IRQ_MIIC2,
        .t_su_sta    = 0,
        .t_hd_sta    = 0,
        .t_su_sto    = 0,
        .t_hd_sto    = 0,
        .output_mode = 2,
        .padmod      = 1,
        .pst_reg     = &i2c2_reg,
    },
};

#define I2C_BUS_NUMBER (sizeof(hal_i2c_cfg_hdl)/sizeof(struct hal_i2c_config))
#endif
