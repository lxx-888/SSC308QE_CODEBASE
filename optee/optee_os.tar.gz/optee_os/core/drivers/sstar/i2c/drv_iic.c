/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <io.h>
#include <irqs.h>
#include <stdio.h>
#include <string.h>
#include <libfdt.h>
#include <initcall.h>
#include <registers.h>
#include <kernel/dt.h>
#include <kernel/boot.h>
#include <kernel/interrupt.h>
#include <kernel/tee_time.h>
#include "drv_iic.h"
#include <iic_os.h>
#include <hal_iic.h>
#include <hal_iic_cfg.h>

/*
 * debug mesg
 */
#define err_msg(fmt, ...)                       \
        do                                          \
        {                                           \
            EMSG("err:" fmt, ##__VA_ARGS__); \
        } while (0)
//#define I2C_DEBUG_MSG
#ifdef I2C_DEBUG_MSG
#define dbg_msg(fmt, ...)                       \
    do                                          \
    {                                           \
        DMSG("dbg:" fmt, ##__VA_ARGS__); \
    } while (0)
#else
#define dbg_msg(fmt, ...)
#endif

#define MIIC_DMA_DONE_TIMEOUT    (10000) // millseconds
#define MIIC_DMA_ALLOC_SIZE      (4096)
#define MIIC_DMA_MIU_BASE_OFFSET (0x10)
#define MIIC_POLLING_TIMEOUT_MS  (2000)
/*
 * value type
 */

struct i2c_async_msg
{
    u32                    size;
    u8 *                   buffer;
    u8                     task_event;
    u16                    msg_flags;
    void *                 reserved;
    sstar_i2c_async_calbck async_callback;
};

struct i2c_control
{
    u32  irq_num;
    char completed;
    char irq_name[20];
    u32  srcclk_num;
    u32 *srcclk_rate;
    struct hal_i2c_ctrl   hal_i2c;
    struct i2c_handler_t *handle;
    struct i2c_async_msg  async_msg;
    const struct hal_i2c_config  *config;
};

/*
 * function definition
 */

static struct i2c_handler_t i2c_handler[I2C_BUS_NUMBER];

struct i2c_handler_t *sstar_i2c_get_handler(u8 port)
{
    u32 i;

    for (i = 0; i < I2C_BUS_NUMBER; i++)
    {
        if (i2c_handler[i].bus_num == port)
            return &i2c_handler[i];
    }

    return NULL;
}

static s32 sstar_i2c_async_done(struct i2c_control *i2c_ctrl)
{
    struct hal_i2c_dma_addr *dma_addr = NULL;

    dma_addr = &i2c_ctrl->hal_i2c.dma_ctrl.dma_addr_msg;
    if (i2c_ctrl->async_msg.msg_flags & MIIC_MSG_RD)
    {
        memcpy(i2c_ctrl->async_msg.buffer, dma_addr->dma_virt_addr, i2c_ctrl->async_msg.size);
    }

    return 0;
}

static enum itr_return sstar_i2c_itr_cb(struct itr_handler *itr_handler)
{
    s32                   ret;
    u32                   async_complet;
    struct i2c_handler_t *handle = (struct i2c_handler_t *)itr_handler->data;
    struct i2c_control   *i2c_ctrl;
    char                  async_done;

    i2c_ctrl = (struct i2c_control *)handle->priv;
    itr_disable(i2c_ctrl->irq_num);

    dbg_msg("i2c intr cb\n");
    ret = hal_i2c_dma_done_clr(&i2c_ctrl->hal_i2c, 1);
    if (ret)
    {
        hal_i2c_wn_mode_clr(&i2c_ctrl->hal_i2c);
        if (i2c_ctrl->async_msg.async_callback)
        {
            hal_i2c_dma_intr_en(&i2c_ctrl->hal_i2c, 0);
            sstar_i2c_async_done(i2c_ctrl);
            async_complet = hal_i2c_dma_trans_cnt(&i2c_ctrl->hal_i2c);
            async_done = (async_complet == i2c_ctrl->async_msg.size) ? 1 : 0;
            i2c_ctrl->async_msg.async_callback(async_done, i2c_ctrl->async_msg.reserved);
        }
        else
        {
            dbg_msg("i2c dma complete\n");
            i2c_ctrl->completed = TRUE;
        }
    }
    itr_enable(i2c_ctrl->irq_num);
    return ITRR_HANDLED;
}

static struct itr_handler i2c_itr = {
    .flags   = ITRF_TRIGGER_LEVEL,
    .handler = sstar_i2c_itr_cb,
};

static void sstar_i2c_itr_init(struct i2c_handler_t *i2c_handle, u32 irq)
{
    i2c_itr.it   = irq;
    i2c_itr.data = (void *)i2c_handle;
    itr_add(&i2c_itr);
    itr_enable(irq);
}

static u32 sstar_i2c_get_systime(void)
{
    TEE_Time current;
    u32      time_ms;

    tee_time_get_sys_time(&current);
    time_ms = current.seconds * 1000 + current.millis;

    return time_ms;
}

static s32 sstar_i2c_dma_callback(void *para_i2c_base)
{
    struct i2c_control  *i2c_ctrl = NULL;
    struct hal_i2c_ctrl *hal_ctrl = (struct hal_i2c_ctrl *)para_i2c_base;
    u32                  trig_time_ms, diff_time_ms;

    i2c_ctrl = container_of(hal_ctrl, struct i2c_control, hal_i2c);

    i2c_ctrl->completed = FALSE;
    hal_i2c_dma_trigger(hal_ctrl);

    if (i2c_ctrl->async_msg.async_callback)
    {
        itr_enable(i2c_ctrl->irq_num);
        dbg_msg("i2c-%u, use async mode\n", hal_ctrl->group);
        return HAL_I2C_OK;
    }
    else
    {
        trig_time_ms = sstar_i2c_get_systime();
        do
        {
            diff_time_ms = sstar_i2c_get_systime() - trig_time_ms;
            if (i2c_ctrl->completed)
                break;
        }while (diff_time_ms < MIIC_POLLING_TIMEOUT_MS);

        if (diff_time_ms >= MIIC_POLLING_TIMEOUT_MS)
        {
            err_msg("i2c-%d DMA TIMEOUT!\n", hal_ctrl->group);
            hal_i2c_dma_reset(hal_ctrl, 1);
            hal_i2c_dma_reset(hal_ctrl, 0);
            return -HAL_I2C_TIMEOUT;
        }
        else
        {
            dbg_msg("i2c-%u DMA DONE!\n", hal_ctrl->group);
        }
    }

    return HAL_I2C_OK;
}

static s32 sstar_i2c_dma_alloc(struct i2c_control *para_i2c_ctrl)
{
    struct hal_i2c_dma_addr *dma_addr;

    dma_addr = &para_i2c_ctrl->hal_i2c.dma_ctrl.dma_addr_msg;
    if (para_i2c_ctrl->hal_i2c.dma_en)
    {
        dma_addr->dma_virt_addr = calloc(1, MIIC_DMA_ALLOC_SIZE);
        dma_addr->dma_phys_addr = virt_to_phys((void *)dma_addr->dma_virt_addr);
        dma_addr->dma_miu_addr  = (u64)(dma_addr->dma_phys_addr - MIU_BASE_OFFSET);
        /*
         *  here offset 0x10,because it may alloc an memory begin miu addr 0x0
         *  if so, as MIIC dma asking for (miu_addr - 1) while asking miu data,
         *  it will hit miu protect, so we add an 0x10 offset
         */
        dma_addr->dma_miu_addr += MIIC_DMA_MIU_BASE_OFFSET;
        dma_addr->dma_phys_addr = (u64)(dma_addr->dma_miu_addr + MIU_BASE_OFFSET);
        dma_addr->dma_virt_addr = (u8 *)phys_to_virt((paddr_t)dma_addr->dma_phys_addr, MEM_AREA_TEE_RAM, (MIIC_DMA_ALLOC_SIZE - MIIC_DMA_MIU_BASE_OFFSET));
    }

    return 0;
}

static s32 sstar_i2c_padmod_set(struct i2c_control *i2c_ctrl)
{
    vaddr_t        va_base;
    struct reg_t  *padmux_reg = NULL;

    if ((!i2c_ctrl) || (!i2c_ctrl->config))
    {
        return -HAL_I2C_SRCCLK_SETUP;
    }

    va_base    = core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1);
    padmux_reg = &i2c_ctrl->config->pst_reg->reg_padmod;

    HAL_I2C_WRITE_WORD_MASK((va_base + padmux_reg->bank_base + (padmux_reg->reg_offset << 2)),
                            i2c_ctrl->config->padmod << padmux_reg->bit_shift, padmux_reg->bit_mask);

    return 0;
}

static s32 sstar_i2c_srclk_en(struct i2c_control *i2c_ctrl, u8 enable)
{
    vaddr_t        va_base;
    struct reg_t  *clkgen_reg_msg = NULL;

    if ((!i2c_ctrl) || (!i2c_ctrl->config))
    {
        return -HAL_I2C_SRCCLK_SETUP;
    }

    va_base        = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    clkgen_reg_msg = &i2c_ctrl->config->pst_reg->reg_clkgen;

    if (enable)
    {
        HAL_I2C_WRITE_WORD_MASK((va_base + clkgen_reg_msg->bank_base + (clkgen_reg_msg->reg_offset << 2)),
                        (0 << clkgen_reg_msg->bit_shift), 0x01 << clkgen_reg_msg->bit_shift);
    }
    else
    {
        HAL_I2C_WRITE_WORD_MASK((va_base + clkgen_reg_msg->bank_base + (clkgen_reg_msg->reg_offset << 2)),
                        (1 << clkgen_reg_msg->bit_shift), 0x01 << clkgen_reg_msg->bit_shift);
    }

    return 0;
}

static void sstar_i2c_match_srcclk(struct i2c_control *i2c_ctrl , u32 speed)
{
    u32 i          = 0;
    u32 diff       = 0;
    u32 min_diff   = 0;
    u32 tmp_rate   = 0;
    u32 match_rate = 0;
    vaddr_t       va_base;
    u8            clkgen_sel     = 0x0;
    struct reg_t *clkgen_reg_msg = NULL;

    if (speed <= HAL_I2C_SPEED_200KHZ)
    {
        tmp_rate                      = 12000000;
        i2c_ctrl->hal_i2c.speed_mode = HAL_I2C_SPEED_NORMAL;
    }
    else if (speed <= HAL_I2C_SPEED_700KHZ)
    {
        tmp_rate                      = 54000000;
        i2c_ctrl->hal_i2c.speed_mode = HAL_I2C_SPEED_HIGH;
    }
    else
    {
        tmp_rate = 72000000;
        i2c_ctrl->hal_i2c.speed_mode = HAL_I2C_SPEED_ULTRA;
    }

    min_diff   = ((u32)~0U);
    match_rate = i2c_ctrl->srcclk_rate[0];
    for (i = 0; i < i2c_ctrl->srcclk_num; i++)
    {
        diff = abs((int)(i2c_ctrl->srcclk_rate[i] - tmp_rate));
        if ((i2c_ctrl->srcclk_rate[i]) > 1 && (diff < min_diff))
        {
            min_diff   = diff;
            match_rate = i2c_ctrl->srcclk_rate[i];
            clkgen_sel = i2c_ctrl->config->pst_reg->src_clk[i].value;
        }
    }
    i2c_ctrl->hal_i2c.match_rate = match_rate;

    va_base        = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    clkgen_reg_msg = &i2c_ctrl->config->pst_reg->reg_clkgen;
    HAL_I2C_WRITE_WORD_MASK((va_base + clkgen_reg_msg->bank_base + (clkgen_reg_msg->reg_offset << 2)),
                    clkgen_sel << clkgen_reg_msg->bit_shift, clkgen_reg_msg->bit_mask);
}

static s32 sstar_i2c_set_srclk(struct i2c_control *i2c_ctrl)
{
    u32 i   = 0;
    struct i2c_reg_t *pst_reg = NULL;

    if ((!i2c_ctrl) || (!i2c_ctrl->config))
    {
        return -HAL_I2C_SRCCLK_SETUP;
    }

    pst_reg = i2c_ctrl->config->pst_reg;

    i2c_ctrl->srcclk_num  = pst_reg->clk_num;

    i2c_ctrl->srcclk_rate = calloc(1, i2c_ctrl->srcclk_num * sizeof(int));
    if (!i2c_ctrl->srcclk_rate)
    {
        return -HAL_I2C_SRCCLK_SETUP;
    }
    memset(i2c_ctrl->srcclk_rate, 0, i2c_ctrl->srcclk_num * sizeof(int));

    for (i = 0; i < i2c_ctrl->srcclk_num; i++)
    {
        i2c_ctrl->srcclk_rate[i] = pst_reg->src_clk[i].rate;
    }

    sstar_i2c_match_srcclk(i2c_ctrl, i2c_ctrl->hal_i2c.speed);

    sstar_i2c_srclk_en(i2c_ctrl, 0);

    return 0;

}

#if 0
static TEE_Result sstar_i2c_probe(const void *fdt, int node, const void *compat_data __unused)
{
    s32 ret      = 0;
    int off      = 0;
    u32 group    = 0;
    u32 speed    = 0;
    u32 handle   = 0;
    u32 dma_en   = 0;
    u32 output   = 0;
    u32 irq_num  = 0;
    u64 io_base  = 0;
    u32 t_su_sta = 0;
    u32 t_hd_sta = 0;
    u32 t_su_sto = 0;
    u32 t_hd_sto = 0;
    struct i2c_control *i2c_ctrl = NULL;
    vaddr_t             va_base;

    dbg_msg("i2c init information comes from dts\n");
    if (_fdt_get_status(fdt, node) != DT_STATUS_OK_SEC)
        return TEE_ERROR_BAD_PARAMETERS;

    i2c_ctrl = calloc(1, sizeof(*i2c_ctrl));
    if (!i2c_ctrl)
    {
        err_msg("i2c alloc fail\n");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    memset(i2c_ctrl, 0, sizeof(struct i2c_control));

    ret = _fdt_read_uint32(fdt, off, "group", &group);
    if (ret)
    {
        err_msg("failed to get i2c group\n");
        goto out1;
    }

    ret = _fdt_read_uint32(fdt, off, "handle", &handle);
    if (ret)
    {
        err_msg("failed to get i2c handle\n");
        goto out1;
    }

    io_base = _fdt_reg_base_address(fdt, off);
    if (io_base == (paddr_t)-1)
    {
        ret = TEE_ERROR_BAD_PARAMETERS;
        err_msg("failed to get i2c-%u reg\n", group);
        goto out1;
    }

    ret = _fdt_read_uint32(fdt, off, "interrupts", &irq_num);
    if (ret)
    {
        err_msg("failed to get i2c-%hhu interrupts\n", group);
        goto out1;
    }


    dma_en = dt_have_prop(fdt, off, "dma-en");

    ret = _fdt_read_uint32(fdt, off, "speed", &speed);
    if (ret)
    {
        speed = 200000;
    }

    ret = _fdt_read_uint32(fdt, off, "t-su-sta", &t_su_sta);
    if (ret)
    {
        t_su_sta = 0;
    }

    ret = _fdt_read_uint32(fdt, off, "t-hd-sta", &t_hd_sta);
    if (ret)
    {
        t_hd_sta = 0;
    }

    ret = _fdt_read_uint32(fdt, off, "t-su-sto", &t_su_sto);
    if (ret)
    {
        t_su_sto = 0;
    }

    ret = _fdt_read_uint32(fdt, off, "t-hd-sta", &t_hd_sto);
    if (ret)
    {
        t_hd_sto = 0;
    }

    ret = _fdt_read_uint32(fdt, off, "output-mode", &output);
    if (ret)
    {
        output = 1;
    }

    i2c_ctrl->handle                              = &i2c_handler[handle];
    i2c_ctrl->completed                           = FALSE;
    i2c_ctrl->irq_num                             = irq_num;
    i2c_ctrl->async_msg.async_callback            = NULL;
    i2c_ctrl->async_msg.buffer                    = NULL;
    i2c_ctrl->hal_i2c.group                       = group;
    i2c_ctrl->hal_i2c.speed                       = speed;
    i2c_ctrl->hal_i2c.dma_en                      = dma_en;
    i2c_ctrl->hal_i2c.output_mode                 = output;
    i2c_ctrl->hal_i2c.clock_count.cnt_stop_hold   = (u16)t_hd_sto;
    i2c_ctrl->hal_i2c.clock_count.cnt_start_setup = (u16)t_su_sta;
    i2c_ctrl->hal_i2c.clock_count.cnt_start_hold  = (u16)t_hd_sta;
    i2c_ctrl->hal_i2c.clock_count.cnt_stop_setup  = (u16)t_su_sto;
    i2c_ctrl->hal_i2c.calbak_dma_transfer         = sstar_i2c_dma_callback;
    va_base                                       = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    i2c_ctrl->hal_i2c.bank_addr                   = va_base + (io_base);

    if (i2c_ctrl->hal_i2c.dma_en)
    {
        if (!snprintf(i2c_ctrl->irq_name, sizeof(i2c_ctrl->irq_name), "i2c%d_Isr", group))
        {
            err_msg("i2c-%hhu irq reformat fail\n", group);
            ret = TEE_ERROR_NOT_SUPPORTED;
            goto out1;
        }
        sstar_i2c_itr_init(i2c_ctrl->handle, i2c_ctrl->irq_num);
        sstar_i2c_dma_alloc(i2c_ctrl);
    }

    ret = sstar_i2c_set_srclk(i2c_ctrl);
    if (ret < 0)
    {
        err_msg("fail to set i2c srcclk\n");
        goto out1;
    }

    sstar_i2c_padmod_set(i2c_ctrl);

    hal_i2c_init(&i2c_ctrl->hal_i2c);

    /*save i2c ctrl struct into i2c_handle->priv*/
    i2c_handler[handle].bus_num = group;
    i2c_handler[handle].priv = i2c_ctrl;
    i2c_handler[handle].bus_init = 1;

    dbg_msg("i2c probe done\n");
    return 0;

out1:
    free(i2c_ctrl);
    return ret;
}

static const struct dt_device_match sstar_i2c_match_table[] = {
    { .compatible = "sstar,i2c" },
    { }
};

DEFINE_DT_DRIVER(sstar_i2c_dt_driver) = {
    .name = "sstar_i2c",
    .type = DT_DRIVER_NOTYPE,
    .match_table = sstar_i2c_match_table,
    .probe = sstar_i2c_probe,
};
#else
static s32 sstar_i2c_probe(struct i2c_handler_t *i2c_handle)
{
    u32                 i;
    s32                 ret;
    vaddr_t             va_base;
    struct i2c_control *i2c_ctrl = NULL;

    dbg_msg("i2c init information comes from config\n");
    if (!i2c_handle)
    {
        err_msg("Invalid Parameter\n");
        return TEE_ERROR_BAD_PARAMETERS;
    }

    i2c_ctrl = calloc(1, sizeof(*i2c_ctrl));
    if (!i2c_ctrl)
    {
        err_msg("i2c-%hhu alloc fail\n", i2c_handle->bus_num);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    memset(i2c_ctrl, 0, sizeof(struct i2c_control));

    for (i = 0; i < I2C_BUS_NUMBER; i++)
    {
        if (i2c_handle->bus_num == hal_i2c_cfg_hdl[i].group)
        {
            i2c_ctrl->config = &hal_i2c_cfg_hdl[i];
            break;
        }
    }
    if (!i2c_ctrl->config)
    {
        err_msg("failed to get i2c-%hhu config message\n", i2c_handle->bus_num);
        ret = TEE_ERROR_BAD_PARAMETERS;
        goto out1;
    }

    i2c_ctrl->handle                              = i2c_handle;
    i2c_ctrl->completed                           = FALSE;
    i2c_ctrl->irq_num                             = i2c_ctrl->config->irq_num;
    i2c_ctrl->async_msg.async_callback            = NULL;
    i2c_ctrl->async_msg.buffer                    = NULL;
    i2c_ctrl->hal_i2c.group                       = i2c_ctrl->config->group;
    i2c_ctrl->hal_i2c.speed                       = i2c_ctrl->config->rate;
    i2c_ctrl->hal_i2c.dma_en                      = i2c_ctrl->config->dma;
    i2c_ctrl->hal_i2c.output_mode                 = i2c_ctrl->config->output_mode;
    i2c_ctrl->hal_i2c.clock_count.cnt_stop_hold   = (u16)i2c_ctrl->config->t_hd_sto;
    i2c_ctrl->hal_i2c.clock_count.cnt_start_setup = (u16)i2c_ctrl->config->t_su_sta;
    i2c_ctrl->hal_i2c.clock_count.cnt_start_hold  = (u16)i2c_ctrl->config->t_hd_sta;
    i2c_ctrl->hal_i2c.clock_count.cnt_stop_setup  = (u16)i2c_ctrl->config->t_su_sto;
    i2c_ctrl->hal_i2c.calbak_dma_transfer         = sstar_i2c_dma_callback;
    va_base                                       = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));
    i2c_ctrl->hal_i2c.bank_addr                   = va_base + (i2c_ctrl->config->io_reg);

    if (i2c_ctrl->hal_i2c.dma_en)
    {
        if (!snprintf(i2c_ctrl->irq_name, sizeof(i2c_ctrl->irq_name), "i2c%d_Isr", i2c_handle->bus_num))
        {
            err_msg("i2c-%hhu irq reformat fail\n", i2c_handle->bus_num);
            ret = TEE_ERROR_BAD_PARAMETERS;
            goto out1;
        }
        sstar_i2c_itr_init(i2c_handle, i2c_ctrl->irq_num);
        sstar_i2c_dma_alloc(i2c_ctrl);
    }

    /*save i2c ctrl struct into i2c_handle->priv*/
    i2c_handle->priv = i2c_ctrl;

    ret = sstar_i2c_set_srclk(i2c_ctrl);
    if (ret < 0)
    {
        err_msg("fail to set i2c srcclk\n");
        goto out1;
    }

    sstar_i2c_padmod_set(i2c_ctrl);

    hal_i2c_init(&i2c_ctrl->hal_i2c);
    dbg_msg("i2c probe done\n");
    return 0;

out1:
    free(i2c_ctrl);
    return ret;
}

static s32 sstar_i2c_handle_init(struct i2c_handler_t *i2c_handle)
{
    s32 ret = 0;

    if (!i2c_handle)
        return TEE_ERROR_NOT_SUPPORTED;

    ret = sstar_i2c_probe(i2c_handle);
    if (ret)
    {
        err_msg("i2c probe fail, return %d\n", ret);
        return ret;
    }

    return 0;
}

static TEE_Result sstar_i2c_driver_init(void)
{
    u32 i   = 0;
    s32 ret = 0;

    for (i = 0; i < I2C_BUS_NUMBER; i++)
    {
        i2c_handler[i].bus_num = hal_i2c_cfg_hdl[i].group;
        ret = sstar_i2c_handle_init(&i2c_handler[i]);
        if (ret < 0)
        {
            err_msg("i2c init fail\n");
            return ret;
        }

        if (!(i2c_handler[i].priv))
        {
            err_msg("i2c handle is NULL\n");
            return TEE_ERROR_NOT_SUPPORTED;
        }
        else
        {
            i2c_handler[i].bus_init = 1;
        }
    }

    return TEE_SUCCESS;
}

driver_init_late(sstar_i2c_driver_init);

#endif

s32 sstar_i2c_master_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num)
{
    s32                 ret;
    s32                 s_ret;
    s32                 msg_cnt;
    struct i2c_control *i2c_ctrl = NULL;
    struct i2c_msg *    msgs     = para_msg;

    i2c_ctrl = (struct i2c_control *)i2c_handle->priv;
    if (!i2c_ctrl)
        return -1;

    if (i2c_ctrl->async_msg.async_callback)
    {
        err_msg("async callback exist,do not call sync API or set it NULL\n");
        return -1;
    }

    sstar_i2c_srclk_en(i2c_ctrl, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 0);
    for (msg_cnt = 0; msg_cnt < para_num; msg_cnt++, msgs++)
    {
        // dma need set stop format before transfer
        if (i2c_ctrl->hal_i2c.dma_en)
        {
            if (!(msgs->flags & 0x02) && (para_num > 1))
            {
                hal_i2c_dma_stop_set(&i2c_ctrl->hal_i2c, ((msgs->flags) & MIIC_MSG_RD));
            }
            else
            {
                hal_i2c_dma_stop_set(&i2c_ctrl->hal_i2c, 1);
            }
        }

        if ((msgs->flags) & MIIC_MSG_RD)
        {
            dbg_msg("I2C READ \n");
            ret = hal_i2c_read(&i2c_ctrl->hal_i2c, msgs->addr, msgs->buf, (u32)msgs->len, msgs->flags);
        }
        else
        {
            dbg_msg("I2C WRITE \n");
            ret = hal_i2c_write(&i2c_ctrl->hal_i2c, msgs->addr, msgs->buf, (u32)msgs->len, msgs->flags);
        }

        if (msgs->flags & 0x02)
            ret = hal_i2c_release(&i2c_ctrl->hal_i2c);

        if (ret)
        {
            break;
        }
    }

    s_ret = hal_i2c_release(&i2c_ctrl->hal_i2c);
    if (s_ret && !ret)
        ret = s_ret;

    if (ret)
    {
        err_msg("i2c-%hhu xfer error: %d\n", i2c_handle->bus_num, ret);
        para_num = -1;
    }
    else
    {
        dbg_msg("i2c-%hhu xfer pass\n", i2c_handle->bus_num);
    }
    sstar_i2c_srclk_en(i2c_ctrl, 0);
    return para_num;
}

s32 sstar_i2c_async_cb_set(struct i2c_handler_t *i2c_handle, sstar_i2c_async_calbck para_cb, void *reserved)
{
    struct i2c_control *i2c_ctrl = (struct i2c_control *)i2c_handle->priv;

    i2c_ctrl->async_msg.async_callback = para_cb;
    i2c_ctrl->async_msg.reserved       = reserved;

    return HAL_I2C_OK;
}

s32 sstar_i2c_master_async_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num)
{
    s32                 ret;
    struct i2c_control *i2c_ctrl = NULL;
    struct i2c_msg *    msgs     = para_msg;


    i2c_ctrl = (struct i2c_control *)i2c_handle->priv;
    if (!i2c_ctrl)
        return -1;

    if (!i2c_ctrl->async_msg.async_callback)
    {
        err_msg("async callback NULL, please setting first\n");
        ret = -HAL_I2C_ERR;
        goto err_out;
    }

    sstar_i2c_srclk_en(i2c_ctrl, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 0);

    if (1 != para_num)
    {
        err_msg("if u want send i2c_msg more than 1,do not use async_xfer\n");
        ret = -HAL_I2C_ERR;
        goto err_out;
    }
    // dma need set stop format before transfer
    if (!i2c_ctrl->hal_i2c.dma_en)
    {
        err_msg("async not support in riu mode\n");
        ret = -HAL_I2C_ERR;
        goto err_out;
    }
    if ((msgs->flags & 0x02) || msgs->flags & MIIC_MSG_RD)
    {
        hal_i2c_dma_stop_set(&i2c_ctrl->hal_i2c, 1);
    }
    else
    {
        hal_i2c_dma_stop_set(&i2c_ctrl->hal_i2c, 0);
    }

    dbg_msg("para number from user is : %d,flags is : 0x%x\n", para_num, msgs->flags);

    i2c_ctrl->async_msg.msg_flags = msgs->flags;
    i2c_ctrl->async_msg.size      = msgs->len;
    if ((msgs->flags) & MIIC_MSG_RD)
    {
        ret                        = hal_i2c_dma_async_read(&i2c_ctrl->hal_i2c, msgs->addr, (u32)msgs->len);
        i2c_ctrl->async_msg.buffer = msgs->buf;
    }
    else
    {
        ret = hal_i2c_dma_async_write(&i2c_ctrl->hal_i2c, msgs->addr, msgs->buf, (u32)msgs->len);
    }

err_out:
    sstar_i2c_srclk_en(i2c_ctrl, 0);

    return ret;
}

s32 sstar_i2c_wnwrite_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num, u8 para_wnlen,
                           u16 para_waitcnt)
{
    s32                 ret;
    struct i2c_control *i2c_ctrl = NULL;
    struct i2c_msg *    msgs     = para_msg;

    i2c_ctrl = (struct i2c_control *)i2c_handle->priv;
    if (!i2c_ctrl)
        return -1;

    if (i2c_ctrl->async_msg.async_callback)
    {
        err_msg("async callback exist,do not call sync API or set it NULL\n");
        return -HAL_I2C_ERR;
    }

    sstar_i2c_srclk_en(i2c_ctrl, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 0);

    if (1 != para_num)
    {
        err_msg("i2c-%u, wn write please send only 1 i2c_msg\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }

    if (!i2c_ctrl->hal_i2c.dma_en)
    {
        err_msg("i2c-%u, riu mode do not support wn write\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }

    if (msgs->flags & MIIC_MSG_RD)
    {
        err_msg("i2c-%u, please do not use wn_write API for reading\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }
    else
    {
        ret = hal_i2c_wn_write(&i2c_ctrl->hal_i2c, msgs->addr, msgs->buf, msgs->len, para_wnlen, para_waitcnt);
        if (ret)
        {
            err_msg("i2c-%u, wn write failed\n", i2c_ctrl->hal_i2c.group);
            ret = -HAL_I2C_ERR;
        }
    }

err_out:
    sstar_i2c_srclk_en(i2c_ctrl, 0);
    return ret;
}

s32 sstar_i2c_wnwrite_async_xfer(struct i2c_handler_t *i2c_handle, struct i2c_msg *para_msg, s32 para_num,
                                 u8 para_wnlen, u16 para_waitcnt)
{
    s32                 ret      = 0;
    struct i2c_control *i2c_ctrl = NULL;
    struct i2c_msg *    msgs     = para_msg;

    i2c_ctrl = (struct i2c_control *)i2c_handle->priv;
    if (!i2c_ctrl)
        return -HAL_I2C_ERR;

    if (!i2c_ctrl->async_msg.async_callback)
    {
        err_msg("async callback NULL, please setting first\n");
        return -HAL_I2C_ERR;
    }

    sstar_i2c_srclk_en(i2c_ctrl, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 1);
    hal_i2c_reset(&i2c_ctrl->hal_i2c, 0);

    if (1 != para_num)
    {
        err_msg("i2c-%u, wn write please send only 1 i2c_msg\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }

    if (!i2c_ctrl->hal_i2c.dma_en)
    {
        err_msg("i2c-%u, riu mode do not support wn write\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }

    if (msgs->flags & MIIC_MSG_RD)
    {
        err_msg("i2c-%u, please do not use wn_write API for reading\n", i2c_ctrl->hal_i2c.group);
        ret = -HAL_I2C_ERR;
        goto err_out;
    }
    else
    {
        i2c_ctrl->async_msg.size      = msgs->len;
        i2c_ctrl->async_msg.msg_flags = msgs->flags;
        ret = hal_i2c_wn_async_write(&i2c_ctrl->hal_i2c, msgs->addr, msgs->buf, msgs->len, para_wnlen, para_waitcnt);
        if (ret)
        {
            err_msg("i2c-%u, wn write failed\n", i2c_ctrl->hal_i2c.group);
            ret = -HAL_I2C_ERR;
            goto err_out;
        }
    }

err_out:
    sstar_i2c_srclk_en(i2c_ctrl, 0);

    return ret;
}

