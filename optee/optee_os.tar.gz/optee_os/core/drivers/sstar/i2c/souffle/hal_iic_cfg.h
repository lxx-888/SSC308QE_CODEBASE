/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HAL_IIC_CFG_H_
#define _HAL_IIC_CFG_H_

#include <irqs.h>

struct hal_i2c_config{
    u32  io_reg;
    u32  irq_num;
    u32  group;
    u32  dma;
    u32  rate;
    u32  tsu_sta;
    u32  thd_sta;
    u32  tsu_sto;
    u32  thd_sto;
    u32  push_pull;
    u32  cnt_optimize;
    u32  max_source_clock;
};


const struct hal_i2c_config hal_i2c_cfg_hdl[] = {

    // i2c-4
    {
        .io_reg    = 0x223000,
        .irq_num   = INT_IRQ_MIIC_0,
        .group     = 4,
        .dma       = 0,
        .rate      = 100000,
        .tsu_sta   = 0,
        .thd_sta   = 0,
        .tsu_sto   = 0,
        .thd_sto   = 0,
        .push_pull = 1,
        .cnt_optimize = 1,
        .max_source_clock = 72000000,
    },
};

#define I2C_BUS_NUMBER  (sizeof(hal_i2c_cfg_hdl)/sizeof(struct hal_i2c_config))
#endif
