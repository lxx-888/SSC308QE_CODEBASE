/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HALTZEMI_H
#define _HALTZEMI_H

#include <drv_tz_common.h>

typedef enum miu_group
{
    MIU_GROUP_SC0       = 0,
    MIU_GROUP_SC1       = 1,
    MIU_GROUP_ISP0      = 2,
    MIU_GROUP_PA        = 7,
} miu_group_t;

typedef enum miu_rd_client
{
    /* SC0 */
    MIU_RD_CLIENT_XD_DECODE     = 0x02,
    MIU_RD_CLIENT_BACH          = 0x03,
    MIU_RD_CLIENT_CMDQ          = 0x04,
    MIU_RD_CLIENT_BDMA          = 0x05,
    MIU_RD_CLIENT_BDMA2         = 0x06,
    MIU_RD_CLIENT_JPE           = 0x07,
    MIU_RD_CLIENT_LOW_SPEED1    = 0x08,
    MIU_RD_CLIENT_SD            = 0x09,
    MIU_RD_CLIENT_CMDQ1         = 0x0A,
    MIU_RD_CLIENT_USB20         = 0x0B,
    MIU_RD_CLIENT_GOP_SC0       = 0x0C,
    MIU_RD_CLIENT_LOW_SPEED0    = 0x0D,
    MIU_RD_CLIENT_SC0_BIST      = 0x0F,
    /* SC1 */
    MIU_RD_CLIENT_VENC_CODEC0   = 0x11,
    MIU_RD_CLIENT_VENC_SAD0     = 0x12,
    MIU_RD_CLIENT_ISP0_CMDQ     = 0x13,
    MIU_RD_CLIENT_AESDMA        = 0x14,
    MIU_RD_CLIENT_LDC           = 0x15,
    MIU_RD_CLIENT_SC_RDMA0      = 0x17,
    MIU_RD_CLIENT_MIIC_TOP      = 0x18,
    MIU_RD_CLIENT_SC_RDMA1      = 0x19,
    MIU_RD_CLIENT_GOP_JPE0      = 0x1B,
    MIU_RD_CLIENT_IVE           = 0x1C,
    MIU_RD_CLIENT_EMAC          = 0x1D,
    MIU_RD_CLIENT_EMAC1         = 0x1E,
    MIU_RD_CLIENT_SC1_BIST      = 0x1F,
    /* ISP0 */
    MIU_RD_CLIENT_ISP_3DNR      = 0x20,
    MIU_RD_CLIENT_ISP_DMAG      = 0x21,
    MIU_RD_CLIENT_ISP_ROT       = 0x25,
    MIU_RD_CLIENT_ISP_WDR       = 0x26,
    MIU_RD_CLIENT_ISP_IIR       = 0x27,
    MIU_RD_CLIENT_ISP_MLOAD     = 0x28,
    MIU_RD_CLIENT_ISP_LDC       = 0x29,
    MIU_RD_CLIENT_ISP0_BIST     = 0x2F,
    /* PA */
    MIU_RD_CLIENT_IPU           = 0x71,
    MIU_RD_CLIENT_CPU           = 0x72,
} miu_rd_client_t;

typedef enum miu_wr_client
{
    /* SC0 */
    MIU_WR_CLIENT_XZ_DECODE     = 0x01,
    MIU_WR_CLIENT_XZ_DECODE2    = 0x02,
    MIU_WR_CLIENT_BACH          = 0x03,
    MIU_WR_CLIENT_BDMA          = 0x05,
    MIU_WR_CLIENT_BDMA2         = 0x06,
    MIU_WR_CLIENT_JPE           = 0x07,
    MIU_WR_CLIENT_LOW_SPEED1    = 0x08,
    MIU_WR_CLIENT_SD            = 0x09,
    MIU_WR_CLIENT_USB20         = 0x0B,
    MIU_WR_CLIENT_LOW_SPEED0    = 0x0D,
    MIU_WR_CLIENT_RIU_RECORDER  = 0x0E,
    MIU_WR_CLIENT_SC0_BIST      = 0x0F,
    /* SC1 */
    MIU_WR_CLIENT_VENC_CODEC0   = 0x11,
    MIU_WR_CLIENT_VENC_SAD0     = 0x12,
    MIU_WR_CLIENT_AESDMA        = 0x14,
    MIU_WR_CLIENT_LDC           = 0x15,
    MIU_WR_CLIENT_SC_WDMA0      = 0x16,
    MIU_WR_CLIENT_MIIC_TOP      = 0x18,
    MIU_WR_CLIENT_SC_WDMA1      = 0x19,
    MIU_WR_CLIENT_SC_WDMA2      = 0x1A,
    MIU_WR_CLIENT_IVE           = 0x1C,
    MIU_WR_CLIENT_EMAC          = 0x1D,
    MIU_WR_CLIENT_EMAC1         = 0x1E,
    MIU_WR_CLIENT_SC1_BIST      = 0x1F,
    /* ISP0 */
    MIU_WR_CLIENT_ISP_3DNR      = 0x20,
    MIU_WR_CLIENT_ISP_DMAGW0    = 0x21,
    MIU_WR_CLIENT_ISP_DMAGW1    = 0x22,
    MIU_WR_CLIENT_ISP_STA       = 0x23,
    MIU_WR_CLIENT_ISP_IMG       = 0x24,
    MIU_WR_CLIENT_ISP_ROT       = 0x25,
    MIU_WR_CLIENT_ISP_WDR       = 0x26,
    MIU_WR_CLIENT_ISP_IIR       = 0x27,
    MIU_WR_CLIENT_ISP0_BIST     = 0x2F,
    /* PA */
    MIU_WR_CLIENT_IPU           = 0x71,
    MIU_WR_CLIENT_CPU           = 0x72,
} miu_wr_client_t;

void tzemi_set_rd_client_prot(miu_rd_client_t client, prot_t ns);
void tzemi_set_all_rd_clients_prot(prot_t ns);
void tzemi_set_wr_client_prot(miu_wr_client_t client, prot_t ns);
void tzemi_set_all_wr_clients_prot(prot_t ns);
void tzemi_set_rd_client_aid(miu_rd_client_t client, unsigned int aid);
void tzemi_set_wr_client_aid(miu_wr_client_t client, unsigned int aid);
void tzemi_set_region_prot(unsigned int region, unsigned int rd_aid, unsigned int wr_aid, bool s_rd_en, bool s_wr_en, bool ns_rd_en, bool ns_wr_en);
void tzemi_set_region_said_rd_en(unsigned int region, unsigned int said_rd_en);
void tzemi_set_region_said_wr_en(unsigned int region, unsigned int said_wr_en);
void tzemi_set_region_nsaid_rd_en(unsigned int region, unsigned int nsaid_rd_en);
void tzemi_set_region_nsaid_wr_en(unsigned int region, unsigned int nsaid_wr_en);
void tzemi_set_region_enable(unsigned int region, bool rd_en, bool wr_en);
void tzemi_set_region_addr(unsigned int region, unsigned long start, unsigned long end);
void tzemi_lock(void);
unsigned int tzemi_get_wr_int_status(void);
unsigned int tzemi_get_rd_int_status(void);
unsigned int tzemi_get_wr_fail_client(void);
unsigned int tzemi_get_rd_fail_client(void);
unsigned int tzemi_get_wr_fail_ns(void);
unsigned int tzemi_get_rd_fail_ns(void);
unsigned int tzemi_get_wr_fail_region(void);
unsigned int tzemi_get_rd_fail_region(void);
unsigned long tzemi_get_wr_fail_addr(void);
unsigned long tzemi_get_rd_fail_addr(void);
void tzemi_mask_int(bool);
void tzemi_clear_int(void);

#endif //_HALTZEMI_H
