/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <kernel/thread.h>
#include <sm/optee_smc.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <hal_tzsp.h>
#include <tzsp_ut.h>

static void tzsp_ut_init(struct thread_smc_args *args)
{
    tzsp_enable_int();

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_set_bank(struct thread_smc_args *args)
{
    riu_bridge_t bridge;
    unsigned int index;
    prot_t ns;

    bridge = args->a2;
    index = args->a4;
    ns = args->a5;

    tzsp_set_bank_prot(bridge, index, ns);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_clr_int(struct thread_smc_args *args)
{
    riu_bridge_t bridge;
    unsigned int rw, type, master;

    bridge = tzsp_get_fail_bridge();

    args->a1 = tzsp_get_fail_bank(bridge);
    args->a2 = tzsp_get_fail_addr(bridge) * 2;
    rw = tzsp_get_fail_rw(bridge);
    type = tzsp_get_fail_type(bridge);
    master = tzsp_get_fail_master(bridge);
    args->a3 = (rw << 6) | (type << 4) | master;
    tzsp_clear_int(bridge);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_set_master(struct thread_smc_args *args)
{
    riu_master_t riu_master = args->a2;
    prot_t ns = args->a3;

    tzsp_set_master_prot(riu_master, ns);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_read_reg(struct thread_smc_args *args)
{
    args->a1 = INREG16(GET_REG_ADDR(GET_BASE_ADDR_BY_BANK( \
                BASE_REG_RIU_PA, args->a2 << 8), args->a3));

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_set_pu(struct thread_smc_args *args)
{
    pu_t pu = args->a2;
    prot_t ns = args->a3;

    tzsp_set_pu_prot(pu, ns);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzsp_ut_read_dla(struct thread_smc_args *args)
{
    vaddr_t dla_va;

    dla_va = core_mmu_get_va(0x19360008, MEM_AREA_IO_SEC, 1);

    args->a1 = *((uint32_t *)dla_va);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

void tzsp_ut(struct thread_smc_args *args)
{
    switch (args->a1) {

    case TZSP_CMD_INIT:
        tzsp_ut_init(args);
        break;

    case TZSP_CMD_SET_BANK:
        tzsp_ut_set_bank(args);
        break;

    case TZSP_CMD_CLR_INT:
        tzsp_ut_clr_int(args);
        break;

    case TZSP_CMD_SET_MASTER:
        tzsp_ut_set_master(args);
        break;

    case TZSP_CMD_READ_REG:
        tzsp_ut_read_reg(args);
        break;

    case TZSP_CMD_SET_PU:
        tzsp_ut_set_pu(args);
        break;

    case TZSP_CMD_READ_DLA:
        tzsp_ut_read_dla(args);
        break;

    default:
        args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
        break;
    }
}
