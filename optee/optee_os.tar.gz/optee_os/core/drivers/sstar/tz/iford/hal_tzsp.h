/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HALTZSP_H
#define _HALTZSP_H

#include <drv_tz_common.h>

#define RIU_BRIDGE_DIG_NS_INDEX_MAX     214
#define RIU_BRIDGE_SC_NS_INDEX_MAX      86
#define RIU_BRIDGE_ISP0_NS_INDEX_MAX    1
#define RIU_BRIDGE_XIU_NS_INDEX_MAX     19
#define RIU_BRIDGE_CMD_NS_INDEX_MAX     7

typedef enum riu_bridge
{
    RIU_BRIDGE_DIG  = 0,
    RIU_BRIDGE_XIU  = 1,
    RIU_BRIDGE_ISP0 = 2,
    RIU_BRIDGE_CMD  = 3,
    RIU_BRIDGE_NONE = 0xFF
} riu_bridge_t;

typedef enum riu_master
{
    RIU_MASTER_DP           = 0,
    RIU_MASTER_RES1         = 1,
    RIU_MASTER_RES2         = 2,
    RIU_MASTER_CMDQ0        = 3,
    RIU_MASTER_CMDQ1        = 4,
    RIU_MASTER_VEN1_VCPU    = 5,
    RIU_MASTER_RES6         = 6,
    RIU_MASTER_RES7         = 7,
    RIU_MASTER_RES8         = 8,
    RIU_MASTER_RES9         = 9,
    RIU_MASTER_RES10        = 10,
    RIU_MASTER_RES11        = 11,
    RIU_MASTER_RES12        = 12,
    RIU_MASTER_RES13        = 13,
    RIU_MASTER_RES14        = 14,
    RIU_MASTER_RES15        = 15,
} riu_master_t;

typedef enum pu
{
    PU_DLA      = 0,
} pu_t;

void tzsp_set_master_prot(riu_master_t master, prot_t ns);
void tzsp_set_pu_prot(pu_t pu, prot_t ns);
void tzsp_set_bank_prot(riu_bridge_t bridge, unsigned int ns_index, prot_t ns);
void tzsp_set_all_banks_prot(prot_t ns);
void tzsp_enable_int(void);
unsigned int tzsp_get_fail_bank(riu_bridge_t bridge);
unsigned long tzsp_get_fail_addr(riu_bridge_t bridge);
unsigned int tzsp_get_fail_rw(riu_bridge_t bridge);
unsigned int tzsp_get_fail_type(riu_bridge_t bridge);
unsigned int tzsp_get_fail_master(riu_bridge_t bridge);
riu_bridge_t tzsp_get_fail_bridge(void);
void tzsp_clear_int(riu_bridge_t bridge);
TEE_Result init_tzsp_itr(void);

#endif //_HALTZSP_H
