/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HALTZIMI_H
#define _HALTZIMI_H

#include <drv_tz_common.h>

typedef enum
{
    IMI_CLIENT_CPU     = 0,
    IMI_CLIENT_VENC0   = 1,
    IMI_CLIENT_AESDMA  = 2,
    IMI_CLIENT_SD30    = 3,
    IMI_CLIENT_BDMA    = 4,
    IMI_CLIENT_SDIO    = 5,
    IMI_CLIENT_FCIE    = 6,
} imi_client_t;

void tzimi_set_client_prot(imi_client_t cli, prot_t ns);
void tzimi_set_riu_access_enable(bool enable);
void tzimi_set_region_prot(unsigned int region, bool s_rd_en, bool s_wr_en, bool ns_rd_en, bool ns_wr_en);
void tzimi_set_region_enable(unsigned int region, bool enable);
void tzimi_set_region_addr(unsigned int region, unsigned long start, unsigned long end);
void tzimi_lock(void);
unsigned int tzimi_get_int_status(void);
unsigned int tzimi_get_fail_client(void);
unsigned long tzimi_get_fail_addr(void);
unsigned int tzimi_get_fail_rw(void);
unsigned int tzimi_get_fail_ns(void);
unsigned int tzimi_get_fail_region(void);
void tzimi_mask_int(bool enable);
void tzimi_force_int(bool enable);
void tzimi_clear_int(void);

#endif //_HALTZIMI_H
