/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _HALTZEMI_H
#define _HALTZEMI_H

#include <drv_tz_common.h>

typedef enum miu_group
{
    MIU_GROUP_SC0       = 1,
    MIU_GROUP_SC1       = 3,
    MIU_GROUP_MISC0     = 4,
    MIU_GROUP_ISP0      = 5,
    MIU_GROUP_PA        = 7,
} miu_group_t;

typedef enum miu_rd_client
{
    /* SC0 */
    MIU_RD_CLIENT_JPE0          = 0x10,
    MIU_RD_CLIENT_USB30         = 0x14,
    MIU_RD_CLIENT_SC_RDMA0      = 0x15,
    MIU_RD_CLIENT_GOP0_SC       = 0x16,
    MIU_RD_CLIENT_JPE           = 0x17,
    MIU_RD_CLIENT_GOP1_SC       = 0x18,
    MIU_RD_CLIENT_JPD           = 0x19,
    MIU_RD_CLIENT_IVE           = 0x1A,
    MIU_RD_CLIENT_AESDMA        = 0x1B,
    MIU_RD_CLIENT_SC_COL_INV    = 0x1C,
    MIU_RD_CLIENT_SC_RDMA1      = 0x1D,
    MIU_RD_CLIENT_MIIC_TOP      = 0x1E,
    MIU_RD_CLIENT_SC0_BIST      = 0x1F,
    /* SC1 */
    MIU_RD_CLIENT_GMAC0         = 0x30,
    MIU_RD_CLIENT_GMAC1         = 0x31,
    MIU_RD_CLIENT_GMAC_TOE0     = 0x32,
    MIU_RD_CLIENT_GMAC_TOE1     = 0x33,
    MIU_RD_CLIENT_GMAC_TOE2     = 0x34,
    MIU_RD_CLIENT_GMAC_TOE3     = 0x35,
    MIU_RD_CLIENT_GMAC_TOE4     = 0x36,
    MIU_RD_CLIENT_GMAC_TOE5     = 0x3A,
    MIU_RD_CLIENT_GMAC_TOE6     = 0x3B,
    MIU_RD_CLIENT_GMAC_TOE7     = 0x3C,
    MIU_RD_CLIENT_SC1_BIST      = 0x3F,
    /* MISC0 */
    MIU_RD_CLIENT_XZ_DECODE     = 0x40,
    MIU_RD_CLIENT_CMDQ1         = 0x41,
    MIU_RD_CLIENT_ISP0_CMDQ     = 0x42,
    MIU_RD_CLIENT_BACH          = 0x43,
    MIU_RD_CLIENT_CMDQ          = 0x44,
    MIU_RD_CLIENT_BDMA          = 0x45,
    MIU_RD_CLIENT_BDMA2         = 0x46,
    MIU_RD_CLIENT_BDMA3         = 0x47,
    MIU_RD_CLIENT_LOW_SPEED1    = 0x48,
    MIU_RD_CLIENT_SD            = 0x49,
    MIU_RD_CLIENT_FCIE          = 0x4A,
    MIU_RD_CLIENT_SDIO          = 0x4B,
    MIU_RD_CLIENT_CVS           = 0x4C,
    MIU_RD_CLIENT_BACH1         = 0x4D,
    MIU_RD_CLIENT_LOWSPEED0     = 0x4E,
    MIU_RD_CLIENT_LDC           = 0x4F,
    /* ISP0 */
    MIU_RD_CLIENT_ISP_DMAGR0    = 0x50,
    MIU_RD_CLIENT_ISP_MLOAD     = 0x51,
    MIU_RD_CLIENT_ISP_3DNR      = 0x52,
    MIU_RD_CLIENT_ISP_TNR       = 0x53,
    MIU_RD_CLIENT_ISP_ROT       = 0x54,
    MIU_RD_CLIENT_ISP_WDR       = 0x55,
    MIU_RD_CLIENT_ISP_DMAGR1    = 0x56,
    MIU_RD_CLIENT_ISP_DMAGR2    = 0x57,
    MIU_RD_CLIENT_ISP_DMAGR3    = 0x58,
    MIU_RD_CLIENT_ISP_FPN       = 0x59,
    MIU_RD_CLIENT_ISP_VENC0     = 0x5E,
    MIU_RD_CLIENT_ISP0_BIST     = 0x5F,
    /* PA */
    MIU_RD_CLIENT_IPU           = 0x71,
    MIU_RD_CLIENT_CPU           = 0x72,
    MIU_RD_CLIENT_VENC0         = 0x73,
    MIU_RD_CLIENT_PA_BIST       = 0x7F,
} miu_rd_client_t;

typedef enum miu_wr_client
{
    /* SC0 */
    MIU_WR_CLIENT_SC_WDMA0      = 0x10,
    MIU_WR_CLIENT_SC_WDMA1      = 0x11,
    MIU_WR_CLIENT_SC_WDMA2      = 0x12,
    MIU_WR_CLIENT_SC_WDMA3      = 0x13,
    MIU_WR_CLIENT_USB30         = 0x14,
    MIU_WR_CLIENT_SC_WDMA4      = 0x15,
    MIU_WR_CLIENT_SC_WDMA5      = 0x16,
    MIU_WR_CLIENT_JPE           = 0x17,
    MIU_WR_CLIENT_SC_WDMA6      = 0x18,
    MIU_WR_CLIENT_JPD0          = 0x19,
    MIU_WR_CLIENT_IVE           = 0x1A,
    MIU_WR_CLIENT_AESDMA        = 0x1B,
    MIU_WR_CLIENT_SC_COL_INV    = 0x1C,
    MIU_WR_CLIENT_MIIC_TOP      = 0x1E,
    MIU_WR_CLIENT_SC0_BIST      = 0x1F,
    /* SC1 */
    MIU_WR_CLIENT_GMAC0         = 0x30,
    MIU_WR_CLIENT_GMAC1         = 0x31,
    MIU_WR_CLIENT_GMAC_TOE0     = 0x32,
    MIU_WR_CLIENT_GMAC_TOE1     = 0x33,
    MIU_WR_CLIENT_GMAC_TOE2     = 0x34,
    MIU_WR_CLIENT_GMAC_TOE3     = 0x35,
    MIU_WR_CLIENT_GMAC_TOE4     = 0x36,
    MIU_WR_CLIENT_GMAC_TOE5     = 0x3A,
    MIU_WR_CLIENT_GMAC_TOE6     = 0x3B,
    MIU_WR_CLIENT_GMAC_TOE7     = 0x3C,
    MIU_WR_CLIENT_SGDMA         = 0x3D,
    MIU_WR_CLIENT_SC1_BIST      = 0x3F,
    /* MISC0 */
    MIU_WR_CLIENT_XZ_DECODE     = 0x40,
    MIU_WR_CLIENT_XZ_DECODE2    = 0x41,
    MIU_WR_CLIENT_BACH          = 0x43,
    MIU_WR_CLIENT_DBG_WDMA      = 0x44,
    MIU_WR_CLIENT_BDMA          = 0x45,
    MIU_WR_CLIENT_BDMA2         = 0x46,
    MIU_WR_CLIENT_BDMA3         = 0x47,
    MIU_WR_CLIENT_LOW_SPEED1    = 0x48,
    MIU_WR_CLIENT_SD            = 0x49,
    MIU_WR_CLIENT_FCIE          = 0x4A,
    MIU_WR_CLIENT_SDIO          = 0x4B,
    MIU_WR_CLIENT_CVS           = 0x4C,
    MIU_WR_CLIENT_BACH1         = 0x4D,
    MIU_WR_CLIENT_LOWSPEED0     = 0x4E,
    MIU_WR_CLIENT_LDC           = 0x4F,
    /* ISP0 */
    MIU_WR_CLIENT_ISP_DMAGR0    = 0x50,
    MIU_WR_CLIENT_ISP_DMAGR1    = 0x51,
    MIU_WR_CLIENT_ISP_3DNR      = 0x52,
    MIU_WR_CLIENT_ISP_WDR       = 0x53,
    MIU_WR_CLIENT_ISP_ROT       = 0x54,
    MIU_WR_CLIENT_ISP_STA       = 0x55,
    MIU_WR_CLIENT_ISP_IMG       = 0x56,
    MIU_WR_CLIENT_ISP_DMAGR2    = 0x57,
    MIU_WR_CLIENT_ISP_DMAGR3    = 0x58,
    MIU_WR_CLIENT_ISP_TNR       = 0x59,
    MIU_WR_CLIENT_ISP_VIF_STA   = 0x5A,
    MIU_WR_CLIENT_ISP_VENC0     = 0x5E,
    MIU_WR_CLIENT_ISP0_BIST     = 0x5F,
    /* PA */
    MIU_WR_CLIENT_IPU           = 0x71,
    MIU_WR_CLIENT_CPU           = 0x72,
    MIU_WR_CLIENT_VENC0         = 0x73,
    MIU_WR_CLIENT_PA_BIST       = 0x7F,
} miu_wr_client_t;

void tzemi_set_rd_client_prot(miu_rd_client_t client, prot_t ns);
void tzemi_set_all_rd_clients_prot(prot_t ns);
void tzemi_set_wr_client_prot(miu_wr_client_t client, prot_t ns);
void tzemi_set_all_wr_clients_prot(prot_t ns);
void tzemi_set_rd_client_aid(miu_rd_client_t client, unsigned int aid);
void tzemi_set_wr_client_aid(miu_wr_client_t client, unsigned int aid);
void tzemi_set_region_prot(unsigned int region, unsigned int rd_aid, unsigned int wr_aid, bool s_rd_en, bool s_wr_en, bool ns_rd_en, bool ns_wr_en);
void tzemi_set_region_said_rd_en(unsigned int region, unsigned int said_rd_en);
void tzemi_set_region_said_wr_en(unsigned int region, unsigned int said_wr_en);
void tzemi_set_region_nsaid_rd_en(unsigned int region, unsigned int nsaid_rd_en);
void tzemi_set_region_nsaid_wr_en(unsigned int region, unsigned int nsaid_wr_en);
void tzemi_set_region_enable(unsigned int region, bool rd_en, bool wr_en);
void tzemi_set_region_addr(unsigned int region, unsigned long start, unsigned long end);
void tzemi_lock(void);
unsigned int tzemi_get_wr_int_status(void);
unsigned int tzemi_get_rd_int_status(void);
unsigned int tzemi_get_wr_fail_client(void);
unsigned int tzemi_get_rd_fail_client(void);
unsigned int tzemi_get_wr_fail_ns(void);
unsigned int tzemi_get_rd_fail_ns(void);
unsigned int tzemi_get_wr_fail_region(void);
unsigned int tzemi_get_rd_fail_region(void);
unsigned long tzemi_get_wr_fail_addr(void);
unsigned long tzemi_get_rd_fail_addr(void);
void tzemi_mask_int(bool);
void tzemi_clear_int(void);

#endif //_HALTZEMI_H
