/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <hal_tz_common.h>

static U8 u8_init = 0, u8_otp_tz = 0;

U8 tz_get_otp_tz(void)
{
#if defined(CFG_ENABLE_TZ_DBG) || defined(CFG_ENABLE_UT)
    (void)u8_init;
    (void)u8_otp_tz;

    return 1;
#else
    if (u8_init == 0)
    {
        u8_otp_tz = (INREG16(GET_REG_ADDR(BASE_REG_OTP2_PA, 0x30)) & BIT9) >> 9;
        u8_init = 1;
    }

    return u8_otp_tz;
#endif
}
