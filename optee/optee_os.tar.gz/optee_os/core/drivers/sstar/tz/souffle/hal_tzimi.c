/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <drivers/gic.h>
#include <kernel/boot.h>
#include <hal_tz_common.h>
#include <hal_tzimi.h>

void tzimi_set_client_prot(imi_client_t cli, prot_t ns)
{
    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x34 + (cli / 16)), 1 << (cli % 16));
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x34 + (cli / 16)), 1 << (cli % 16));
}

void tzimi_set_riu_access_enable(bool enable)
{
    if (!tz_get_otp_tz())
        return;

    if (enable == TRUE)
    {
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x3C), 1);
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), 1);
    }
    else
    {
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x3C), 1);
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), 1);
    }
}

void tzimi_set_region_prot(unsigned int region, bool s_rd_en, bool s_wr_en, bool ns_rd_en, bool ns_wr_en)
{
    unsigned int val = 0, ns_wr_rd_en = 0;

    if (!tz_get_otp_tz())
        return;

    val = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x30));
    ns_wr_rd_en = (val & (BIT9 | BIT8)) >> 8;

    switch (region)
    {
        case 0:
            if (s_rd_en == TRUE)
                val |= BIT10;
            else
                val &= ~BIT10;

            if (s_wr_en == TRUE)
                val |= BIT11;
            else
                val &= ~BIT11;

            if (ns_rd_en == TRUE)
                val |= BIT6;
            else
                val &= ~BIT6;

            if (ns_wr_en == TRUE)
                val |= BIT7;
            else
                val &= ~BIT7;

            OUTREGMSK16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x30), val, 0x0CC0);
            SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), BIT0);
            break;

        case 1:
            if (s_rd_en == TRUE)
                val |= BIT14;
            else
                val &= ~BIT14;

            if (s_wr_en == TRUE)
                val |= BIT15;
            else
                val &= ~BIT15;

            if (ns_rd_en == TRUE)
                val |= BIT12;
            else
                val &= ~BIT12;

            if (ns_wr_en == TRUE)
                val |= BIT13;
            else
                val &= ~BIT13;

            //process BIT7(wr_en) & BIT6(rd_en) of region 0
            val &= ~(BIT7|BIT6);
            val |= ns_wr_rd_en << 6;
            OUTREGMSK16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x30), val, 0xF0C0);
            SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), BIT0);
            break;

        default:
            EMSG("only region 0/1 are valid\r\n");
            break;
    }
}

void tzimi_set_region_enable(unsigned int region, bool enable)
{
    unsigned int val = 0, ns_wr_rd_en = 0;

    if (!tz_get_otp_tz())
        return;

    val = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x30));
    ns_wr_rd_en = (val & (BIT9 | BIT8)) >> 8;

    switch (region)
    {
        case 0:
            EMSG("region 0 is always enabled\r\n");
            break;

        case 1:
            if (enable == TRUE)
                val |= BIT0;
            else
                val &= ~BIT0;

            //process BIT7(wr_en) & BIT6(rd_en) of region 0
            val &= ~(BIT7|BIT6);
            val |= ns_wr_rd_en << 6;
            OUTREGMSK16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x30), val, 0x00C1);
            SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), BIT0);
            break;

        default:
            EMSG("only region 0/1 are valid\r\n");
            break;
    }
}

void tzimi_set_region_addr(unsigned int region, unsigned long start, unsigned long end)
{
    if (!tz_get_otp_tz())
        return;

    switch (region)
    {
        case 0:
            EMSG("region 0 address cannot set\r\n");
            break;

        case 1:
            OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x38), (start & 0xFFFF));
            OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x39), ((start >> 16) & 0xFFFF));
            OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x3A), (end & 0xFFFF));
            OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x3B), ((end >> 16) & 0xFFFF));
            SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), BIT0);
            break;

        default:
            EMSG("only region 0/1 are valid\r\n");
            break;
    }
}

void tzimi_lock(void)
{
    if (!tz_get_otp_tz())
        return;

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), BIT1);
}

unsigned int tzimi_get_int_status(void)
{
    unsigned int status;

    if (!tz_get_otp_tz())
        return 0;

    status = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x40));

    return status;
}

unsigned int tzimi_get_fail_client(void)
{
    unsigned int client = 0, val = 0, i = 0;

    if (!tz_get_otp_tz())
        return 0;

    val = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x44));

    for (i = 0; i < 16; i++)
        if (val & (1 << i))
        {
            client = i;
            break;
        }

    return client;
}

unsigned long tzimi_get_fail_addr(void)
{
    unsigned long lo, hi;

    if (!tz_get_otp_tz())
        return 0;

    lo = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x45));
    hi = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x46));

    return ((hi << 16) + lo);
}

unsigned int tzimi_get_fail_rw(void)
{
    unsigned int rw;

    if (!tz_get_otp_tz())
        return 0;

    rw = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x47)) & BIT0);

    return rw;
}

unsigned int tzimi_get_fail_ns(void)
{
    unsigned int ns;

    if (!tz_get_otp_tz())
        return 0;

    ns = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x47)) & BIT1) >> 1;

    return ns;
}

unsigned int tzimi_get_fail_region(void)
{
    unsigned int region;

    if (!tz_get_otp_tz())
        return 0;

    region = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x47)) & BIT2) >> 2;

    return region;
}

void tzimi_mask_int(bool enable)
{
    if (!tz_get_otp_tz())
        return;

    if (enable == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x41), BIT0);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x41), BIT0);
}

void tzimi_force_int(bool enable)
{
    if (!tz_get_otp_tz())
        return;

    if (enable == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x42), BIT0);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x42), BIT0);
}

void tzimi_clear_int(void)
{
    if (!tz_get_otp_tz())
        return;

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x43), BIT0);
}

#ifdef CFG_ENABLE_G1S_INT
static enum itr_return tzimi_itr_cb(struct itr_handler *h __maybe_unused)
{
    itr_disable(INT_IRQ_TZIMI);

    if (tzimi_get_int_status())
    {
        EMSG("[TZIMI] %s fail: Client=0x%x Region=0x%x NS=0x%x Addr=0x%lx\n",
            tzimi_get_fail_rw() ? "Write" : "Read",
            tzimi_get_fail_client(),
            tzimi_get_fail_region(),
            tzimi_get_fail_ns(),
            tzimi_get_fail_addr()
        );
    }

    tzimi_clear_int();
    itr_enable(INT_IRQ_TZIMI);

    return ITRR_HANDLED;
}

static struct itr_handler tzimi_itr = {
    .it = INT_IRQ_TZIMI,
    .flags = ITRF_TRIGGER_LEVEL,
    .handler = tzimi_itr_cb,
};

static TEE_Result init_tzimi_itr(void)
{
    itr_add_type_prio(&tzimi_itr, IRQ_TYPE_LEVEL_HIGH, 0);
    itr_enable(INT_IRQ_TZIMI);

    return TEE_SUCCESS;
}

driver_init(init_tzimi_itr);
#endif
