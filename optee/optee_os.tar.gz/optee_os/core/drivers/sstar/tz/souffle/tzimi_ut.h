/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef TZIMI_UT_H
#define TZIMI_UT_H

#define TZIMI_CMD_INIT                  0xA000
#define TZIMI_CMD_SET_REGION_PROT       0xA001
#define TZIMI_CMD_SET_REGION_ADDR       0xA002
#define TZIMI_CMD_SET_REGION_ENABLE     0xA003
#define TZIMI_CMD_CLR_INT               0xA004
#define TZIMI_CMD_SET_CLIENT            0xA005
#define TZIMI_CMD_READ_REG              0xA006
#define TZIMI_CMD_WRITE_REG             0xA007
#define TZIMI_CMD_SET_LOAD              0xA008
#define TZIMI_CMD_SET_LOCK              0xA009
#define TZIMI_CMD_SET_RIU_ACCESS        0xA00A
#define TZIMI_CMD_READ_MEM              0xA00B
#define TZIMI_CMD_WRITE_MEM             0xA00C

void tzimi_ut(struct thread_smc_args *args);

#endif /* TZIMI_UT_H */
