/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <sm/optee_smc.h>
#include <hal_tzmisc.h>

void tzmisc_set_reg_select_spi(spi_domain_t domain)
{
    if (domain == NONPM)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZMISC, 0x00), BIT0);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZMISC, 0x00), BIT0);
}

void tzmisc_func(struct thread_smc_args *args)
{
    switch (args->a1) {
        case OPTEE_SMC_TZMISC_SET_REG_SELECT_SPI_NONPM:
            tzmisc_set_reg_select_spi(NONPM);
            args->a0 = OPTEE_SMC_RETURN_OK;
            break;

        case OPTEE_SMC_TZMISC_SET_REG_SELECT_SPI_PM:
            tzmisc_set_reg_select_spi(PM);
            args->a0 = OPTEE_SMC_RETURN_OK;
            break;

        default:
            args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
            break;
    }
}
