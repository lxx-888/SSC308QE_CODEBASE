/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef TZSP_UT_H
#define TZSP_UT_H

#define TZSP_CMD_INIT           0xA000
#define TZSP_CMD_SET_BANK       0xA001
#define TZSP_CMD_CLR_INT        0xA002
#define TZSP_CMD_SET_MASTER     0xA003
#define TZSP_CMD_READ_REG       0xA004
#define TZSP_CMD_SET_PU         0xA005
#define TZSP_CMD_READ_DLA       0xA006

void tzsp_ut(struct thread_smc_args *args);

#endif /* TZSP_UT_H */
