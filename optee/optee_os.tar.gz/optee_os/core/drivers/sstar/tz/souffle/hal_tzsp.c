/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <drivers/gic.h>
#include <kernel/boot.h>
#include <hal_tz_common.h>
#include <hal_tzsp.h>

static unsigned long tzsp_get_tzsp_riu_bank(riu_bridge_t bridge)
{
    unsigned long tzsp_riu_bank = REG_ADDR_BASE_DIG_TZSP_RIU;

    if (bridge == RIU_BRIDGE_DIG)
        tzsp_riu_bank = REG_ADDR_BASE_DIG_TZSP_RIU;
    else if (bridge == RIU_BRIDGE_XIU)
        tzsp_riu_bank = REG_ADDR_BASE_XIU_TZSP_RIU;
    else if (bridge == RIU_BRIDGE_ISP0)
        tzsp_riu_bank = REG_ADDR_BASE_ISP0_TZSP_RIU;
    else if (bridge == RIU_BRIDGE_CMD)
        tzsp_riu_bank = REG_ADDR_BASE_CMD_TZSP_RIU;
    else if (bridge == RIU_BRIDGE_SC)
        tzsp_riu_bank = REG_ADDR_BASE_SC_TZSP_RIU;

    return tzsp_riu_bank;
}

static unsigned long tzsp_get_riu_dbg_bank(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = REG_ADDR_BASE_DIG_RIU_DBG;

    if (bridge == RIU_BRIDGE_DIG)
        riu_dbg_bank = REG_ADDR_BASE_DIG_RIU_DBG;
    else if (bridge == RIU_BRIDGE_XIU)
        riu_dbg_bank = REG_ADDR_BASE_XIU_RIU_DBG;
    else if (bridge == RIU_BRIDGE_ISP0)
        riu_dbg_bank = REG_ADDR_BASE_ISP0_RIU_DBG;
    else if (bridge == RIU_BRIDGE_CMD)
        riu_dbg_bank = REG_ADDR_BASE_CMD_RIU_DBG;
    else if (bridge == RIU_BRIDGE_SC)
        riu_dbg_bank = REG_ADDR_BASE_SC_RIU_DBG;

    return riu_dbg_bank;
}

void tzsp_set_master_prot(riu_master_t master, prot_t ns)
{
    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZSP, 0x00), 1 << master);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZSP, 0x00), 1 << master);
}

void tzsp_set_pu_prot(pu_t pu, prot_t ns)
{
    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZSP, 0x01), 1 << pu);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZSP, 0x01), 1 << pu);
}

void tzsp_set_bank_prot(riu_bridge_t bridge, unsigned int ns_index, prot_t ns)
{
    unsigned long bank_tzsp_riu = tzsp_get_tzsp_riu_bank(bridge);

    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(bank_tzsp_riu, (ns_index / 16)), (1 << (ns_index % 16)));
    else
        CLRREG16(GET_REG_ADDR(bank_tzsp_riu, (ns_index / 16)), (1 << (ns_index % 16)));
}

void tzsp_set_all_banks_prot(prot_t ns)
{
    unsigned int ns_index;

    if (!tz_get_otp_tz())
        return;

    for (ns_index = 0; ns_index <= RIU_BRIDGE_DIG_NS_INDEX_MAX; ns_index++)
        tzsp_set_bank_prot(RIU_BRIDGE_DIG, ns_index, ns);

    for (ns_index = 0; ns_index <= RIU_BRIDGE_SC_NS_INDEX_MAX; ns_index++)
        tzsp_set_bank_prot(RIU_BRIDGE_SC, ns_index, ns);

    for (ns_index = 0; ns_index <= RIU_BRIDGE_ISP0_NS_INDEX_MAX; ns_index++)
        tzsp_set_bank_prot(RIU_BRIDGE_ISP0, ns_index, ns);

    for (ns_index = 0; ns_index <= RIU_BRIDGE_XIU_NS_INDEX_MAX; ns_index++)
        tzsp_set_bank_prot(RIU_BRIDGE_XIU, ns_index, ns);

    for (ns_index = 0; ns_index <= RIU_BRIDGE_CMD_NS_INDEX_MAX; ns_index++)
        tzsp_set_bank_prot(RIU_BRIDGE_CMD, ns_index, ns);
}

void tzsp_enable_int(void)
{
    if (!tz_get_otp_tz())
        return;

    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZSP, 0x10), BIT0);
    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_DIG_RIU_DBG, 0x43), 0xFFFF);
    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_XIU_RIU_DBG, 0x43), 0xFFFF);
    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_ISP0_RIU_DBG, 0x43), 0xFFFF);
    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_CMD_RIU_DBG, 0x43), 0xFFFF);
    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_SC_RIU_DBG, 0x43), 0xFFFF);
}

unsigned int tzsp_get_fail_bank(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);
    unsigned int bank;

    if (!tz_get_otp_tz())
        return 0;

    bank = ((INREG16(GET_REG_ADDR(riu_dbg_bank, 0x41)) & 0x00FF) << 8)
        + ((INREG16(GET_REG_ADDR(riu_dbg_bank, 0x40)) & 0xFF00) >> 8);

    return bank;
}

unsigned long tzsp_get_fail_addr(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);
    unsigned long addr;

    if (!tz_get_otp_tz())
        return 0;

    addr = (INREG16(GET_REG_ADDR(riu_dbg_bank, 0x40)) & 0x00FF) / 2;

    return addr;
}

unsigned int tzsp_get_fail_rw(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);
    unsigned int rw;

    if (!tz_get_otp_tz())
        return 0;

    rw = (INREG16(GET_REG_ADDR(riu_dbg_bank, 0x41)) & 0x0300) >> 8;

    if (rw == 1)
        return 1;
    else if (rw == 2)
        return 0;
    else
    {
        EMSG("invalid rw=0x%x", rw);
        return 0;
    }
}

unsigned int tzsp_get_fail_type(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);
    unsigned int type;

    if (!tz_get_otp_tz())
        return 0;

    type = (INREG16(GET_REG_ADDR(riu_dbg_bank, 0x41)) & 0x0C00) >> 10;

    if (type == 2)
        return 1;
    else if (type == 1)
        return 2;
    else
    {
        EMSG("invalid type=0x%x", type);
        return 0;
    }
}

unsigned int tzsp_get_fail_master(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);
    unsigned int master;

    if (!tz_get_otp_tz())
        return 0;

    master = (INREG16(GET_REG_ADDR(riu_dbg_bank, 0x41)) & 0xF000) >> 12;

    return master;
}

riu_bridge_t tzsp_get_fail_bridge(void)
{
    unsigned int val;

    if (!tz_get_otp_tz())
        return 0;

    val = INREG16(GET_REG_ADDR(REG_ADDR_BASE_DIG_GP_CTRL, 0x31)) & 0x001F;

    if (val & BIT0)
        return RIU_BRIDGE_DIG;
    else if (val & BIT1)
        return RIU_BRIDGE_XIU;
    else if (val & BIT2)
        return RIU_BRIDGE_CMD;
    else if (val & BIT3)
        return RIU_BRIDGE_ISP0;
    else if (val & BIT4)
        return RIU_BRIDGE_SC;
    else
        return RIU_BRIDGE_NONE;
}

void tzsp_clear_int(riu_bridge_t bridge)
{
    unsigned long riu_dbg_bank = tzsp_get_riu_dbg_bank(bridge);

    if (!tz_get_otp_tz())
        return;

    OUTREG16(GET_REG_ADDR(riu_dbg_bank, 0x42), 0xFF);
}

#ifdef CFG_ENABLE_G1S_INT
static enum itr_return tzsp_itr_cb(struct itr_handler *h __maybe_unused)
{
    riu_bridge_t bridge = RIU_BRIDGE_NONE;

    itr_disable(INT_IRQ_RIU_ERROR_RESP);

    while ((bridge = tzsp_get_fail_bridge()) != RIU_BRIDGE_NONE)
    {
        EMSG("[TZSP] %s fail: Master=0x%x Type=0x%x Bank=0x%x Addr=0x%x\n",
                tzsp_get_fail_rw(bridge) ? "Write" : "Read",
                tzsp_get_fail_master(bridge),
                tzsp_get_fail_type(bridge),
                tzsp_get_fail_bank(bridge),
                tzsp_get_fail_addr(bridge)
            );
        tzsp_clear_int(bridge);
    }

    itr_enable(INT_IRQ_RIU_ERROR_RESP);

    return ITRR_HANDLED;
}

static struct itr_handler tzsp_itr = {
    .it = INT_IRQ_RIU_ERROR_RESP,
    .flags = ITRF_TRIGGER_LEVEL,
    .handler = tzsp_itr_cb,
};

TEE_Result init_tzsp_itr(void)
{
    itr_add_type_prio(&tzsp_itr, IRQ_TYPE_LEVEL_HIGH, 0);
    itr_enable(INT_IRQ_RIU_ERROR_RESP);
    tzsp_enable_int();

    return TEE_SUCCESS;
}

driver_init(init_tzsp_itr);
#endif
