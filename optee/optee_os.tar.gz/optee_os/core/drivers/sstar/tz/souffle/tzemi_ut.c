/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <kernel/thread.h>
#include <sm/optee_smc.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <hal_tzemi.h>
#include <tzemi_ut.h>

static void tzemi_ut_init(struct thread_smc_args *args)
{
    tzemi_mask_int(FALSE);

    core_mmu_add_mapping(MEM_AREA_IO_SEC, args->a2, args->a3 - args->a2 + 1);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_region_prot(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    unsigned int said_rd_en = args->a3;
    unsigned int said_wr_en = args->a4;
    unsigned int nsaid_rd_en = args->a5;
    unsigned int nsaid_wr_en = args->a6;

    tzemi_set_region_said_rd_en(region, said_rd_en);
    tzemi_set_region_said_wr_en(region, said_wr_en);
    tzemi_set_region_nsaid_rd_en(region, nsaid_rd_en);
    tzemi_set_region_nsaid_wr_en(region, nsaid_wr_en);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_region_addr(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    unsigned long start = args->a3;
    unsigned long end = args->a4;

    tzemi_set_region_addr(region, start, end);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_region_enable(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    bool rd_en = args->a3;
    bool wr_en = args->a4;

    tzemi_set_region_enable(region, rd_en, wr_en);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_clr_int(struct thread_smc_args *args)
{
    unsigned int wr_region, wr_ns, wr_status, wr_client;
    unsigned int rd_region, rd_ns, rd_status, rd_client;
    unsigned long wr_addr, rd_addr;

    wr_region = tzemi_get_wr_fail_region();
    wr_status = tzemi_get_wr_int_status();
    wr_ns = tzemi_get_wr_fail_ns();
    wr_client = tzemi_get_wr_fail_client();
    wr_addr = tzemi_get_wr_fail_addr();

    rd_region = tzemi_get_rd_fail_region();
    rd_status = tzemi_get_rd_int_status();
    rd_ns = tzemi_get_rd_fail_ns();
    rd_client = tzemi_get_rd_fail_client();
    rd_addr = tzemi_get_rd_fail_addr();

    args->a1 = (wr_region << 27) | (wr_status << 26) | (wr_ns << 25) | (wr_client << 16) \
                | (rd_region << 11) | (rd_status << 10) | (rd_ns << 9) | rd_client;
    args->a2 = wr_addr;
    args->a3 = rd_addr;

    tzemi_clear_int();

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_wr_client(struct thread_smc_args *args)
{
    miu_wr_client_t miu_wr_client = args->a2;
    prot_t ns = args->a3;
    unsigned int aid = args->a4;

    tzemi_set_wr_client_prot(miu_wr_client, ns);
    tzemi_set_wr_client_aid(miu_wr_client, aid);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_rd_client(struct thread_smc_args *args)
{
    miu_rd_client_t miu_rd_client = args->a2;
    prot_t ns = args->a3;
    unsigned int aid = args->a4;

    tzemi_set_rd_client_prot(miu_rd_client, ns);
    tzemi_set_rd_client_aid(miu_rd_client, aid);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_read_reg(struct thread_smc_args *args)
{
    args->a1 = INREG16(GET_REG_ADDR(GET_BASE_ADDR_BY_BANK( \
                BASE_REG_RIU_PA, args->a2 << 8), args->a3));

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_write_reg(struct thread_smc_args *args)
{
    OUTREG16(GET_REG_ADDR(GET_BASE_ADDR_BY_BANK( \
            BASE_REG_RIU_PA, args->a2 << 8), args->a3), args->a4);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_set_load(struct thread_smc_args *args)
{
    switch (args->a2) {

    case 0x1618:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    case 0x1619:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_MIU_TZ_PA, 0x20), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    case 0x161A:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_MIU_TZ_ISP0, 0x20), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    case 0x161B:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_MIU_TZ_MISC0, 0x20), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    case 0x161D:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_MIU_TZ_SC0, 0x20), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    case 0x161E:
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_MIU_TZ_SC1, 0x20), 1);
        args->a0 = OPTEE_SMC_RETURN_OK;
        break;

    default:
        args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
        break;
    }
}

static void tzemi_ut_set_lock(struct thread_smc_args *args)
{
    tzemi_lock();

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_read_mem(struct thread_smc_args *args)
{
    vaddr_t emi_va;

    emi_va = core_mmu_get_va(args->a2, MEM_AREA_IO_SEC, 1);

    args->a1 = *((uint8_t *)emi_va);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzemi_ut_write_mem(struct thread_smc_args *args)
{
    vaddr_t emi_va;

    emi_va = core_mmu_get_va(args->a2, MEM_AREA_IO_SEC, 1);

    *((uint8_t *)emi_va) = (uint8_t)(args->a3);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

void tzemi_ut(struct thread_smc_args *args)
{
    switch (args->a1) {

    case TZEMI_CMD_INIT:
        tzemi_ut_init(args);
        break;

    case TZEMI_CMD_SET_REGION_PROT:
        tzemi_ut_set_region_prot(args);
        break;

    case TZEMI_CMD_SET_REGION_ADDR:
        tzemi_ut_set_region_addr(args);
        break;

    case TZEMI_CMD_SET_REGION_ENABLE:
        tzemi_ut_set_region_enable(args);
        break;

    case TZEMI_CMD_CLR_INT:
        tzemi_ut_clr_int(args);
        break;

    case TZEMI_CMD_SET_WR_CLIENT:
        tzemi_ut_set_wr_client(args);
        break;

    case TZEMI_CMD_SET_RD_CLIENT:
        tzemi_ut_set_rd_client(args);
        break;

    case TZEMI_CMD_READ_REG:
        tzemi_ut_read_reg(args);
        break;

    case TZEMI_CMD_WRITE_REG:
        tzemi_ut_write_reg(args);
        break;

    case TZEMI_CMD_SET_LOAD:
        tzemi_ut_set_load(args);
        break;

    case TZEMI_CMD_SET_LOCK:
        tzemi_ut_set_lock(args);
        break;

    case TZEMI_CMD_READ_MEM:
        tzemi_ut_read_mem(args);
        break;

    case TZEMI_CMD_WRITE_MEM:
        tzemi_ut_write_mem(args);
        break;

    default:
        args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
        break;
    }
}
