/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <drivers/gic.h>
#include <kernel/boot.h>
#include <hal_tz_common.h>
#include <hal_tzemi.h>

static unsigned long tzemi_get_miu_group_tz_bank(miu_group_t group)
{
    unsigned long miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_PA;

    if (group == MIU_GROUP_PA)
        miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_PA;
    else if (group == MIU_GROUP_SC0)
        miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_SC0;
    else if (group == MIU_GROUP_SC1)
        miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_SC1;
    else if (group == MIU_GROUP_MISC0)
        miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_MISC0;
    else if (group == MIU_GROUP_ISP0)
        miu_group_tz_bank = REG_ADDR_BASE_MIU_TZ_ISP0;

    return miu_group_tz_bank;
}

void tzemi_set_rd_client_prot(miu_rd_client_t client, prot_t ns)
{
    unsigned long miu_group_tz_bank = tzemi_get_miu_group_tz_bank((client & 0xF0) >> 4);

    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(miu_group_tz_bank, 0x10 + (client & 0xF)), BIT4);
    else
        CLRREG16(GET_REG_ADDR(miu_group_tz_bank, 0x10 + (client & 0xF)), BIT4);

    SETREG16(GET_REG_ADDR(miu_group_tz_bank, 0x20), BIT0);
}

void tzemi_set_all_rd_clients_prot(prot_t ns)
{
    unsigned int index;

    if (!tz_get_otp_tz())
        return;

    for (index = 0; index <= 15; index++)
        tzemi_set_rd_client_prot((MIU_GROUP_SC0 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_rd_client_prot((MIU_GROUP_SC1 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_rd_client_prot((MIU_GROUP_MISC0 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_rd_client_prot((MIU_GROUP_ISP0 << 4) | index, ns);

    tzemi_set_rd_client_prot((MIU_GROUP_PA << 4) | 1, ns);
    tzemi_set_rd_client_prot((MIU_GROUP_PA << 4) | 3, ns);
}

void tzemi_set_wr_client_prot(miu_wr_client_t client, prot_t ns)
{
    unsigned long miu_group_tz_bank = tzemi_get_miu_group_tz_bank((client & 0xF0) >> 4);

    if (!tz_get_otp_tz())
        return;

    if (ns == PROT_NS)
        SETREG16(GET_REG_ADDR(miu_group_tz_bank, client & 0xF), BIT4);
    else
        CLRREG16(GET_REG_ADDR(miu_group_tz_bank, client & 0xF), BIT4);

    SETREG16(GET_REG_ADDR(miu_group_tz_bank, 0x20), BIT0);
}

void tzemi_set_all_wr_clients_prot(prot_t ns)
{
    unsigned int index;

    if (!tz_get_otp_tz())
        return;

    for (index = 0; index <= 15; index++)
        tzemi_set_wr_client_prot((MIU_GROUP_SC0 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_wr_client_prot((MIU_GROUP_SC1 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_wr_client_prot((MIU_GROUP_MISC0 << 4) | index, ns);

    for (index = 0; index <= 15; index++)
        tzemi_set_wr_client_prot((MIU_GROUP_ISP0 << 4) | index, ns);

    tzemi_set_wr_client_prot((MIU_GROUP_PA << 4) | 1, ns);
    tzemi_set_wr_client_prot((MIU_GROUP_PA << 4) | 3, ns);
}

void tzemi_set_rd_client_aid(miu_rd_client_t client, unsigned int aid)
{
    unsigned long miu_group_tz_bank = tzemi_get_miu_group_tz_bank((client & 0xF0) >> 4);

    if (!tz_get_otp_tz())
        return;

    if (aid > 15)
    {
        EMSG("aid is 0 ~ 15\r\n");
        return;
    }

    OUTREGMSK16(GET_REG_ADDR(miu_group_tz_bank, 0x10 + (client & 0xF)), aid, 0xF);
    SETREG16(GET_REG_ADDR(miu_group_tz_bank, 0x20), BIT0);
}

void tzemi_set_wr_client_aid(miu_wr_client_t client, unsigned int aid)
{
    unsigned long miu_group_tz_bank = tzemi_get_miu_group_tz_bank((client & 0xF0) >> 4);

    if (!tz_get_otp_tz())
        return;

    if (aid > 15)
    {
        EMSG("aid is 0 ~ 15\r\n");
        return;
    }

    OUTREGMSK16(GET_REG_ADDR(miu_group_tz_bank, client & 0xF), aid, 0xF);
    SETREG16(GET_REG_ADDR(miu_group_tz_bank, 0x20), BIT0);
}

void tzemi_set_region_prot(unsigned int region, unsigned int rd_aid, unsigned int wr_aid, bool s_rd_en, bool s_wr_en, bool ns_rd_en, bool ns_wr_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    if (rd_aid > 15 || wr_aid > 15)
    {
        EMSG("aid is 0 ~ 15\r\n");
        return;
    }

    if (s_rd_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x68 + region)), 1 << rd_aid);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x68 + region)), 1 << rd_aid);

    if (s_wr_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x57 + region)), 1 << wr_aid);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x57 + region)), 1 << wr_aid);

    if (ns_rd_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x46 + region)), 1 << rd_aid);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x46 + region)), 1 << rd_aid);

    if (ns_wr_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x35 + region)), 1 << wr_aid);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x35 + region)), 1 << wr_aid);

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_said_rd_en(unsigned int region, unsigned int said_rd_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x68 + region)), said_rd_en);
    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_said_wr_en(unsigned int region, unsigned int said_wr_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x57 + region)), said_wr_en);
    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_nsaid_rd_en(unsigned int region, unsigned int nsaid_rd_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x46 + region)), nsaid_rd_en);
    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_nsaid_wr_en(unsigned int region, unsigned int nsaid_wr_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (0x35 + region)), nsaid_wr_en);
    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_enable(unsigned int region, bool rd_en, bool wr_en)
{
    if (!tz_get_otp_tz())
        return;

    if (region == 0)
    {
        EMSG("region 0 is always enabled\r\n");
        return;
    }
    else if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    if (rd_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x33), 1 << (region - 1));
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x33), 1 << (region - 1));

    if (wr_en == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x34), 1 << (region - 1));
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x34), 1 << (region - 1));

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_set_region_addr(unsigned int region, unsigned long start, unsigned long end)
{
    if (!tz_get_otp_tz())
        return;

    if (region == 0 && start != 0)
    {
        EMSG("region 0 start is always 0\r\n");
        return;
    }
    else if (region > 16)
    {
        EMSG("region number is 0 ~ 16\r\n");
        return;
    }

    if (region == 0)
    {
        OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x01), end & 0xFFFF);
        OUTREGMSK16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x22), (end & 0x00FF0000) >> 8, 0x0000FF00);
    }
    else
    {
        OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (region * 2)), start & 0xFFFF);
        OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (region * 2 + 0x01)), end & 0xFFFF);
        OUTREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, (region + 0x22)), ((end & 0xFF0000) >> 8) + ((start & 0xFF0000) >> 16));
    }

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT0);
}

void tzemi_lock(void)
{
    if (!tz_get_otp_tz())
        return;

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT10);
}

unsigned int tzemi_get_wr_int_status(void)
{
    unsigned int status;

    if (!tz_get_otp_tz())
        return 0;

    status = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7A)) & BIT10) >> 10;

    return status;
}

unsigned int tzemi_get_rd_int_status(void)
{
    unsigned int status;

    if (!tz_get_otp_tz())
        return 0;

    status = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7B)) & BIT10) >> 10;

    return status;
}

unsigned int tzemi_get_wr_fail_client(void)
{
    unsigned int client;

    if (!tz_get_otp_tz())
        return 0;

    client = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7A)) & 0x1FF);

    return client;
}

unsigned int tzemi_get_rd_fail_client(void)
{
    unsigned int client;

    if (!tz_get_otp_tz())
        return 0;

    client = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7B)) & 0x1FF);

    return client;
}

unsigned int tzemi_get_wr_fail_ns(void)
{
    unsigned int ns;

    if (!tz_get_otp_tz())
        return 0;

    ns = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7A)) & 0x200) >> 9;

    return ns;
}

unsigned int tzemi_get_rd_fail_ns(void)
{
    unsigned int ns;

    if (!tz_get_otp_tz())
        return 0;

    ns = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7B)) & 0x200) >> 9;

    return ns;
}

unsigned int tzemi_get_wr_fail_region(void)
{
    unsigned int region;

    if (!tz_get_otp_tz())
        return 0;

    region = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7A)) & 0xF800) >> 11;

    return region;
}

unsigned int tzemi_get_rd_fail_region(void)
{
    unsigned int region;

    if (!tz_get_otp_tz())
        return 0;

    region = (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7B)) & 0xF800) >> 11;

    return region;
}

unsigned long tzemi_get_wr_fail_addr(void)
{
    unsigned long addr;

    if (!tz_get_otp_tz())
        return 0;

    addr = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7C))
        + (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7D)) << 16);

    return addr;
}

unsigned long tzemi_get_rd_fail_addr(void)
{
    unsigned long addr;

    if (!tz_get_otp_tz())
        return 0;

    addr = INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7E))
        + (INREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x7F)) << 16);

    return addr;
}

void tzemi_mask_int(bool enable)
{
    if (!tz_get_otp_tz())
        return;

    if (enable == TRUE)
        SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT8);
    else
        CLRREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT8);
}

void tzemi_clear_int(void)
{
    if (!tz_get_otp_tz())
        return;

    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZEMI, 0x79), BIT9);
}

#ifdef CFG_ENABLE_G1S_INT
static enum itr_return tzemi_itr_cb(struct itr_handler *h __maybe_unused)
{
    itr_disable(INT_IRQ_TZEMI);

    if (tzemi_get_rd_int_status())
    {
        EMSG("[TZEMI] Read fail: Client=0x%x Region=0x%x NS=0x%x Addr=0x%lx\n",
            tzemi_get_rd_fail_client(),
            tzemi_get_rd_fail_region(),
            tzemi_get_rd_fail_ns(),
            tzemi_get_rd_fail_addr()
        );
    }

    if (tzemi_get_wr_int_status())
    {
        EMSG("[TZEMI] Write fail: Client=0x%x Region=0x%x NS=0x%x Addr=0x%lx\n",
            tzemi_get_wr_fail_client(),
            tzemi_get_wr_fail_region(),
            tzemi_get_wr_fail_ns(),
            tzemi_get_wr_fail_addr()
        );
    }

    tzemi_clear_int();
    itr_enable(INT_IRQ_TZEMI);

    return ITRR_HANDLED;
}

static struct itr_handler tzemi_itr = {
    .it = INT_IRQ_TZEMI,
    .flags = ITRF_TRIGGER_LEVEL,
    .handler = tzemi_itr_cb,
};

static TEE_Result init_tzemi_itr(void)
{
    itr_add_type_prio(&tzemi_itr, IRQ_TYPE_LEVEL_HIGH, 0);
    itr_enable(INT_IRQ_TZEMI);

    return TEE_SUCCESS;
}

driver_init(init_tzemi_itr);
#endif
