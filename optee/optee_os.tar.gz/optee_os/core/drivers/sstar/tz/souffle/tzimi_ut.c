/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <kernel/thread.h>
#include <sm/optee_smc.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <hal_tzimi.h>
#include <tzimi_ut.h>

register_phys_mem_pgdir(MEM_AREA_IO_SEC, IMI_BASE, IMI_MAP_SIZE);

static void tzimi_ut_init(struct thread_smc_args *args)
{
    tzimi_mask_int(FALSE);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_region_prot(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    bool s_rd_en = args->a3;
    bool s_wr_en = args->a4;
    bool ns_rd_en = args->a5;
    bool ns_wr_en = args->a6;

    tzimi_set_region_prot(region, s_rd_en, s_wr_en, ns_rd_en, ns_wr_en);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_region_addr(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    unsigned long start = args->a3;
    unsigned long end = args->a4;

    tzimi_set_region_addr(region, start, end);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_region_enable(struct thread_smc_args *args)
{
    unsigned int region = args->a2;
    bool enable = args->a3;

    tzimi_set_region_enable(region, enable);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_clr_int(struct thread_smc_args *args)
{
    unsigned int client, rw, ns, region;

    client = tzimi_get_fail_client();
    rw = tzimi_get_fail_rw();
    ns = tzimi_get_fail_ns();
    region = tzimi_get_fail_region();

    args->a1 = (region << 6) | (ns << 5) | (rw << 4) | client;
    args->a2 = tzimi_get_fail_addr();
    tzimi_clear_int();

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_client(struct thread_smc_args *args)
{
    imi_client_t imi_client = args->a2;
    prot_t ns = args->a3;

    tzimi_set_client_prot(imi_client, ns);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_read_reg(struct thread_smc_args *args)
{
    args->a1 = INREG16(GET_REG_ADDR(GET_BASE_ADDR_BY_BANK( \
                BASE_REG_RIU_PA, args->a2 << 8), args->a3));

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_write_reg(struct thread_smc_args *args)
{
    OUTREG16(GET_REG_ADDR(GET_BASE_ADDR_BY_BANK( \
            BASE_REG_RIU_PA, args->a2 << 8), args->a3), args->a4);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_load(struct thread_smc_args *args)
{
    SETREG16(GET_REG_ADDR(REG_ADDR_BASE_TZIMI, 0x31), 1);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_lock(struct thread_smc_args *args)
{
    tzimi_lock();

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_set_riu_access(struct thread_smc_args *args)
{
    tzimi_set_riu_access_enable(args->a2);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_read_mem(struct thread_smc_args *args)
{
    vaddr_t imi_va;

    imi_va = core_mmu_get_va(args->a2, MEM_AREA_IO_SEC, 1);

    args->a1 = *((uint8_t *)imi_va);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

static void tzimi_ut_write_mem(struct thread_smc_args *args)
{
    vaddr_t imi_va;

    imi_va = core_mmu_get_va(args->a2, MEM_AREA_IO_SEC, 1);

    *((uint8_t *)imi_va) = (uint8_t)(args->a3);

    args->a0 = OPTEE_SMC_RETURN_OK;
}

void tzimi_ut(struct thread_smc_args *args)
{
    switch (args->a1) {

    case TZIMI_CMD_INIT:
        tzimi_ut_init(args);
        break;

    case TZIMI_CMD_SET_REGION_PROT:
        tzimi_ut_set_region_prot(args);
        break;

    case TZIMI_CMD_SET_REGION_ADDR:
        tzimi_ut_set_region_addr(args);
        break;

    case TZIMI_CMD_SET_REGION_ENABLE:
        tzimi_ut_set_region_enable(args);
        break;

    case TZIMI_CMD_CLR_INT:
        tzimi_ut_clr_int(args);
        break;

    case TZIMI_CMD_SET_CLIENT:
        tzimi_ut_set_client(args);
        break;

    case TZIMI_CMD_READ_REG:
        tzimi_ut_read_reg(args);
        break;

    case TZIMI_CMD_WRITE_REG:
        tzimi_ut_write_reg(args);
        break;

    case TZIMI_CMD_SET_LOAD:
        tzimi_ut_set_load(args);
        break;

    case TZIMI_CMD_SET_LOCK:
        tzimi_ut_set_lock(args);
        break;

    case TZIMI_CMD_SET_RIU_ACCESS:
        tzimi_ut_set_riu_access(args);
        break;

    case TZIMI_CMD_READ_MEM:
        tzimi_ut_read_mem(args);
        break;

    case TZIMI_CMD_WRITE_MEM:
        tzimi_ut_write_mem(args);
        break;

    default:
        args->a0 = OPTEE_SMC_RETURN_UNKNOWN_FUNCTION;
        break;
    }
}
