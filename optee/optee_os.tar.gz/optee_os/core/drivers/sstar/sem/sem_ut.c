/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <compiler.h>
#include <sm/optee_smc.h>
#include <trace.h>
#include <user_ta_header.h>
#include <sstar_types.h>
#include <drv_sem.h>
#include <sem_ut.h>

static U32 sem_ut(void)
{
    DMSG("SEM UT start\n");

    MDrv_SEM_Init();
    MDrv_SEM_Lock(E_SEM_AESDMA, SEM_WAIT_FOREVER);
    MDrv_SEM_Unlock(E_SEM_AESDMA);

    DMSG("SEM UT done\n");

    return OPTEE_SMC_RETURN_OK;
}

TEE_Result sem_ut_pta(uint32_t nParamTypes, TEE_Param pParams[TEE_NUM_PARAMS])
{
    (void)pParams;

    if (nParamTypes != TEE_PARAM_TYPES(TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE,
                         TEE_PARAM_TYPE_NONE))
                         return TEE_ERROR_BAD_PARAMETERS;

    sem_ut();
    return TEE_SUCCESS;
}
