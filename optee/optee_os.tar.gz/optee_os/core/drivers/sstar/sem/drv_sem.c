/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <kernel/tee_time.h>
#include <sstar_types.h>
#include <sstar_platform.h>
#include <drv_sem.h>
#include <hal_sem.h>

//-------------------------------------------------------------------------------------------------
//  Local Defines
//-------------------------------------------------------------------------------------------------
#define SEM_RESOURCE_ID SEM_ARM_S_ID

BOOL         _gbSEMInitialized = FALSE;
static struct mutex stMutex[E_SEM_MAX_NUM];

//-------------------------------------------------------------------------------------------------
//  Debug Functions
//-------------------------------------------------------------------------------------------------
#define SEM_PRINT IMSG
#define SEM_DEBUG DMSG
#define SEM_ERROR EMSG
#define SEM_WARN  EMSG

#define SEM_MUTEX_CREATE(_index)        MDrv_CreateMutex(_index)
#define SEM_MUTEX_LOCK(_index, _waitms) MDrv_ObtainMutex(_index, _waitms)
#define SEM_MUTEX_UNLOCK(_index)        MDrv_ReleaseMutex(_index)

//-------------------------------------------------------------------------------------------------
// Gloabal Functions
//-------------------------------------------------------------------------------------------------
static BOOL MDrv_CreateMutex(S32 s32MutexId)
{
    mutex_init(&stMutex[s32MutexId]);
    return TRUE;
}

static BOOL MDrv_ObtainMutex(S32 s32MutexId, U32 u32WaitMs)
{
    BOOL bRet = FALSE;

    if (u32WaitMs == MSOS_WAIT_FOREVER) // blocking wait
    {
        mutex_lock(&stMutex[s32MutexId]);
        bRet = TRUE;
    }
    else if (u32WaitMs == 0) // non-blocking
    {
        if (!mutex_trylock(&stMutex[s32MutexId]))
        {
            bRet = TRUE;
        }
    }
    else // blocking wait with timeout
    {
        mutex_lock(&stMutex[s32MutexId]);
        bRet = TRUE;
    }
    return bRet;
}

static BOOL MDrv_ReleaseMutex(S32 s32MutexId)
{
    mutex_unlock(&stMutex[s32MutexId]);
    return TRUE;
}

static U32 MDrv_GetSystemTime(void)
{
    TEE_Time current;
    U32 system_timer = 0;

    tee_time_get_sys_time(&current);
    system_timer = current.seconds * 1000 + current.millis;

    return system_timer;
}

//-------------------------------------------------------------------------------------------------
/// Attempt to create mutex
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Init(void)
{
    S32 s32Index;

    if (_gbSEMInitialized)
        return TRUE;

    for (s32Index = 0; s32Index < E_SEM_MAX_NUM; s32Index++)
    {
        SEM_MUTEX_CREATE(s32Index);
        SEM_DEBUG("s32Index = %d\n", s32Index);
    }

    _gbSEMInitialized = TRUE;
    return TRUE;
}

//-------------------------------------------------------------------------------------------------
/// Attempt to get resource
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Get_Resource(U8 u8SemID, U16 u16ResId)
{
    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    return HAL_SEM_Get_Resource(u8SemID, u16ResId);
}

//-------------------------------------------------------------------------------------------------
/// Attempt to free resource
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Free_Resource(U8 u8SemID, U16 u16ResId)
{
    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    return HAL_SEM_Free_Resource(u8SemID, u16ResId);
}

//-------------------------------------------------------------------------------------------------
/// Attempt to reset resource
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Reset_Resource(U8 u8SemID)
{
    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    return HAL_SEM_Reset_Resource(u8SemID);
}

//-------------------------------------------------------------------------------------------------
/// Attempt to get resource ID
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Get_ResourceID(U8 u8SemID, U16* pu16ResId)
{
    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    return HAL_SEM_Get_ResourceID(u8SemID, pu16ResId);
}

//-------------------------------------------------------------------------------------------------
/// Attempt to get semaphore number
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
U32 MDrv_SEM_Get_Num(void)
{
    return HAL_SEM_Get_Num();
}

//-------------------------------------------------------------------------------------------------
/// Attempt to lock a hardware semaphore
/// @param  SemId       \b IN: hardware semaphore ID
/// @param  u32WaitMs   \b IN: 0 ~ SEM_WAIT_FOREVER: suspend time (ms) if the mutex is locked
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Lock(eSemId SemId, U32 u32WaitMs)
{
    S16  s16SemId;
    BOOL bRet;
    U32  u32SysOldTime, u32Interval;

    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    SEM_DEBUG("Lock SemId = %d\n", SemId);
    SEM_DEBUG("Lock u32WaitMs = %d\n", u32WaitMs);

    bRet          = FALSE;
    s16SemId      = HAL_SEM_GetSemId(SemId);
    u32SysOldTime = MDrv_GetSystemTime();
    u32Interval   = 0;

    if (s16SemId < 0)
    {
        SEM_ERROR("Lock SemId%d invalid\n", SemId);
        return FALSE;
    }

    SEM_DEBUG("Lock s16SemId = %d\n", s16SemId);

    /*blocking*/
    if (u32WaitMs == SEM_WAIT_FOREVER)
    {
        bRet = SEM_MUTEX_LOCK(s16SemId, MSOS_WAIT_FOREVER);

        if (bRet == FALSE)
        {
            SEM_ERROR("Obtain mutex %d failed\n", s16SemId);
        }
        else
        {
            do
            {
                bRet = HAL_SEM_Get_Resource((U8)s16SemId, SEM_RESOURCE_ID);
            } while (bRet != TRUE);

            if (bRet == FALSE)
            {
                SEM_MUTEX_UNLOCK(s16SemId);
                SEM_ERROR("Obtain hardware semaphore %d failed\n", s16SemId);
            }
        }
    }
    /*blocking with timeout*/
    else
    {
        bRet = SEM_MUTEX_LOCK(s16SemId, (u32WaitMs - u32Interval));

        if (bRet == FALSE)
        {
            SEM_ERROR("Obtain mutex %d failed\n", s16SemId);
        }
        else
        {
            do
            {
                bRet        = HAL_SEM_Get_Resource((U8)s16SemId, SEM_RESOURCE_ID);
                u32Interval = MDrv_GetSystemTime() - u32SysOldTime;
            } while ((bRet != TRUE) && (u32Interval < u32WaitMs));

            if (bRet == FALSE)
            {
                SEM_MUTEX_UNLOCK(s16SemId);
                SEM_ERROR("Obtain hardware semaphore %d failed, timeout=%d\n", s16SemId, u32WaitMs);
            }
        }
    }

    return bRet;
}

//-------------------------------------------------------------------------------------------------
/// Attempt to unlock a hardware semaphore
/// @param  SemId       \b IN: hardware semaphore ID
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Unlock(eSemId SemId)
{
    S16  s16SemId;
    BOOL bRet;

    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    bRet = FALSE;
    SEM_DEBUG("Unlock SemId = %d\n", SemId);
    s16SemId = HAL_SEM_GetSemId(SemId);

    if (s16SemId < 0)
    {
        SEM_ERROR("Unlock SemId%d invalid\n", SemId);
        return FALSE;
    }

    SEM_DEBUG("Unlock s16SemId = %d\n", s16SemId);

    bRet = HAL_SEM_Free_Resource((U8)s16SemId, SEM_RESOURCE_ID);

    if (bRet == FALSE)
    {
        SEM_ERROR("Release hardware semaphore %d failed\n", s16SemId);
    }

    SEM_MUTEX_UNLOCK(s16SemId);

    return bRet;
}

//-------------------------------------------------------------------------------------------------
/// Attempt to delete a hardware semaphore
/// @param  SemId       \b IN: hardware semaphore ID
/// @return TRUE : succeed
/// @return FALSE : fail
//-------------------------------------------------------------------------------------------------
BOOL MDrv_SEM_Delete(eSemId SemId)
{
    S16  s16SemId;
    BOOL bRet;

    if (!_gbSEMInitialized)
    {
        SEM_WARN("%s is called before init\n", __FUNCTION__);
        return FALSE;
    }

    bRet = FALSE;
    SEM_DEBUG("Delete SemId = %d\n", SemId);
    s16SemId = HAL_SEM_GetSemId(SemId);

    if (s16SemId < 0)
    {
        return FALSE;
    }

    bRet = SEM_MUTEX_UNLOCK(s16SemId);

    if (bRet == FALSE)
    {
        SEM_ERROR("Release mutex %d failed\n", s16SemId);
    }
    else
    {
        bRet = HAL_SEM_Reset_Resource((U8)s16SemId);

        if (bRet == FALSE)
        {
            SEM_ERROR("Reset hardware semaphore %d failed\n", s16SemId);
        }
    }

    return bRet;
}
