/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <hal_sem.h>
#include <drv_sem.h>

//-------------------------------------------------------------------------------------------------
//  Local Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Local Variables
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Local Structures
//-------------------------------------------------------------------------------------------------
const eSemId SemIdTbl[SEM_MAX_CLIENT] = {SEM_ID};

S16 HAL_SEM_GetSemId(eSemId eSemID)
{
    U8 idx;

    for (idx = 0; idx < SEM_MAX_CLIENT; idx++)
        if (eSemID == SemIdTbl[idx])
            return idx;
    return (-1);
}

U32 HAL_SEM_Get_Num(void)
{
    return SEM_MAX_NUM;
}

BOOL HAL_SEM_Get_Resource(U8 u8SemID, U16 u16ResId)
{
    if (u8SemID > SEM_MAX_NUM)
        return FALSE;

    OUTREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID), u16ResId);
    return (u16ResId == INREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID))) ? TRUE : FALSE;
}

BOOL HAL_SEM_Free_Resource(U8 u8SemID, U16 u16ResId)
{
    if (u8SemID > SEM_MAX_NUM)
        return FALSE;

    if (u16ResId != INREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID)))
    {
        return FALSE;
    }

    OUTREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID), 0x00);
    return TRUE;
}

BOOL HAL_SEM_Reset_Resource(U8 u8SemID)
{
    if (u8SemID > SEM_MAX_NUM)
        return FALSE;

    OUTREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID), 0x00);
    return TRUE;
}

BOOL HAL_SEM_Get_ResourceID(U8 u8SemID, U16* pu16ResId)
{
    if (u8SemID > SEM_MAX_NUM)
        return FALSE;

    *pu16ResId = INREG16(GET_REG_ADDR(BASE_REG_SEM_PA, u8SemID));
    return TRUE;
}
