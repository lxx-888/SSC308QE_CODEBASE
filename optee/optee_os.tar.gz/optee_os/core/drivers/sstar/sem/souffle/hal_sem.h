/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef __HAL_SEM_H__
#define __HAL_SEM_H__

#include <sstar_types.h>
#include <drv_sem.h>

//-------------------------------------------------------------------------------------------------
//   Macro and Define
//-------------------------------------------------------------------------------------------------
#define SEM_MAX_NUM    (16)
#define SEM_MAX_CLIENT (E_SEM_MAX_NUM)
#define SEM_ID         E_SEM_AESDMA

BOOL HAL_SEM_Get_Resource(U8 u8SemID, U16 u16ResId);
BOOL HAL_SEM_Free_Resource(U8 u8SemID, U16 u16ResId);
BOOL HAL_SEM_Reset_Resource(U8 u8SemID);
BOOL HAL_SEM_Get_ResourceID(U8 u8SemID, U16* pu16ResId);
U32  HAL_SEM_Get_Num(void);
S16  HAL_SEM_GetSemId(eSemId SemId);

#endif // #ifndef __HAL_SEM_H__
