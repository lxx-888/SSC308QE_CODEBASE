/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <sstar_types.h>
#include <sstar_platform.h>
#include <registers.h>
#include <irqs.h>
#include <mic.h>

void ss_mic_irq_mask(u32 irq_num)
{
    s32 ss_irq;
    s32 ss_fiq;

    ss_irq = irq_num - GIC_SPI_MS_IRQ_START;
    ss_fiq = irq_num - GIC_SPI_MS_IRQ_START - GIC_SPI_MS_IRQ_NR;

    if (ss_fiq >= 0 && ss_fiq < GIC_SPI_MS_FIQ_NR)
    {
        SETREG16_BIT_OP((BASE_REG_INTRCTL_PA + REG_ID_44 + (ss_fiq / 16) * 4), (1 << (ss_fiq % 16)));
        INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
    }
    else if (ss_irq >= 0 && ss_irq < GIC_SPI_MS_IRQ_NR)
    {
        if (ss_irq >= 0 && ss_irq < INT_IRQ_BANK2_BASE)
        {
            SETREG16_BIT_OP((BASE_REG_INTRCTL_PA + REG_ID_54 + (ss_irq / 16) * 4), (1 << (ss_irq % 16)));
            INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
        }
        else
        {
            SETREG16_BIT_OP((BASE_REG_INTRCTL2_PA + REG_ID_54 + ((ss_irq - INT_IRQ_BANK2_BASE) / 16) * 4),
                            (1 << ((ss_irq - INT_IRQ_BANK2_BASE) % 16)));
            INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
        }
    }
    else
    {
        EMSG("[%s] Unknown irq_num %u\n", __func__, irq_num);
        return;
    }
}

void ss_mic_irq_unmask(u32 irq_num)
{
    s32 ss_irq;
    s32 ss_fiq;

    ss_irq = irq_num - GIC_SPI_MS_IRQ_START;
    ss_fiq = irq_num - GIC_SPI_MS_IRQ_START - GIC_SPI_MS_IRQ_NR;

    if (ss_fiq >= 0 && ss_fiq < GIC_SPI_MS_FIQ_NR)
    {
        CLRREG16_BIT_OP((BASE_REG_INTRCTL_PA + REG_ID_44 + (ss_fiq / 16) * 4), (1 << (ss_fiq % 16)));
        INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
    }
    else if (ss_irq >= 0 && ss_irq < GIC_SPI_MS_IRQ_NR)
    {
        if (ss_irq >= 0 && ss_irq < INT_IRQ_BANK2_BASE)
        {
            CLRREG16_BIT_OP((BASE_REG_INTRCTL_PA + REG_ID_54 + (ss_irq / 16) * 4), (1 << (ss_irq % 16)));
            INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
        }
        else
        {
            CLRREG16_BIT_OP((BASE_REG_INTRCTL2_PA + REG_ID_54 + ((ss_irq - INT_IRQ_BANK2_BASE) / 16) * 4),
                            (1 << ((ss_irq - INT_IRQ_BANK2_BASE) % 16)));
            INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
        }
    }
    else
    {
        EMSG("[%s] Unknown irq_num %u\n", __func__, irq_num);
        return;
    }
}

void ss_mic_irq_eoi(u32 irq_num)
{
    s32 ss_fiq;

    ss_fiq = irq_num - GIC_SPI_MS_IRQ_START - GIC_SPI_MS_IRQ_NR;

    if (ss_fiq >= 0 && ss_fiq < GIC_SPI_MS_FIQ_NR)
    {
        SETREG16_BIT_OP((BASE_REG_INTRCTL_PA + REG_ID_4C + (ss_fiq / 16) * 4), (1 << (ss_fiq % 16)));
        INREG16(BASE_REG_MAILBOX_PA); // read a register make ensure the previous write command was compeleted
    }
    else if (ss_fiq >= GIC_SPI_MS_FIQ_NR)
    {
        EMSG("[%s] Unknown irq_num %u, ss_fiq %d\n", __func__, irq_num, ss_fiq);
        return;
    }
}
