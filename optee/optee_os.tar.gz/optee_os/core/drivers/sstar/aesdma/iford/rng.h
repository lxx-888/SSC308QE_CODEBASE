/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#ifndef _RNG_H__
#define _RNG_H__


#include <assert.h>
#include <stdint.h>
#include <kernel/delay.h>
#include <mm/core_memprot.h>
#include <tee/cache.h>

#define AESDMA0_BANK_BASE       0x112200
#define AESDMA1_BANK_BASE       0x112e00
#define RNG_BANK_BASE           0x112f00
#define RNG_CLK_BANK_BASE       0x103f00

//aesdma2
#define REG_HT_CTRL                    0x00
#define REG_HT_RINGOSC_SEL             0x09
#define REG_HT_TRIGER_SEL              0x0A
#define REG_HT_INT_MASK2               0x0D
#define REG_AES_SCA_CTRL               0x20
#define REG_SCA_STATUS                 0x24

// RNG Control
#define AESDMA_SW_RST                   (1<<7)

//RNG
#define REG_RNG_NUM_OUT                 0x0022
#define REG_RNG_CTRL                    0x0023

uint8_t sstar_get_random_byte(void);
TEE_Result crypto_sstar_rng_read(void *buf, size_t blen);

#endif // _RNG_H__

