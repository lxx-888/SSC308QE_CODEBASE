/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <rng.h>

uint32_t gu32_aesdma_io_virtaddr;


#define REG16(bank, addr)           (*((volatile uint16_t *)((gu32_aesdma_io_virtaddr+(bank<<1U)) + ((addr)<<2U))))
#define REG32(bank, addr)           (*((volatile uint32_t *)((gu32_aesdma_io_virtaddr+(bank<<1U)) + ((addr)<<2U))))

#define AESDMA0_REG16(addr)              (REG16(AESDMA0_BANK_BASE, addr))
#define AESDMA1_REG16(addr)              (REG16(AESDMA1_BANK_BASE, addr))

#define RNGCLK_REG16(addr)               (REG16(RNG_CLK_BANK_BASE, addr))

#define AESDMA0_REG32(addr)              (REG32(AESDMA0_BANK_BASE, addr))
#define AESDMA1_REG32(addr)              (REG32(AESDMA1_BANK_BASE, addr))


static uint16_t sstar_rng_init(void)
{
    gu32_aesdma_io_virtaddr  = (core_mmu_get_va(RIU_BASE, MEM_AREA_IO_SEC, 1));

    if((AESDMA0_REG16(REG_RNG_CTRL) & 0x8000) != 0x8000)
    {
        uint64_t timeout;

        AESDMA1_REG16(REG_HT_RINGOSC_SEL) = 0x4321;
        AESDMA1_REG16(REG_HT_TRIGER_SEL)  = 0xFF00; //clk rc =12M
        AESDMA1_REG16(REG_HT_INT_MASK2)   = 0xFFFF;

        if((RNGCLK_REG16(0x77) & 0x40) != 0x40)
            AESDMA1_REG16(REG_HT_CTRL) = 0x8070;
        else
            AESDMA1_REG16(REG_HT_CTRL) = 0x0070;

        //rng restart
        AESDMA0_REG16(REG_RNG_CTRL) = 0x0001;
        AESDMA0_REG16(REG_RNG_CTRL) = 0x0000;

        while((AESDMA0_REG16(REG_RNG_CTRL) & 0x8000) != 0x8000)
        {
            timeout = timeout_init_us(500); //wait 500us
            if(timeout_elapsed(timeout))
            {
                return 0;//timout
            }
        }
    }

    return 1;

}

static uint16_t sstar_rng_hw_read(void)
{
    return AESDMA0_REG16(REG_RNG_NUM_OUT);
}

static void sstar_rng_read(void *buf, uint32_t blen)
{
    uint16_t *data = buf;
    uint32_t i;

    for(i = 0; i < blen; i++)
    {
        data[i] = sstar_rng_hw_read();
    }
    /*
    for(i = 0; i < blen; i++)
    {
        EMSG(" %"PRIx16,  data[i]);
    }*/
}


static TEE_Result do_rng_read(void *buf, uint32_t blen)
{
    static int rng_init_flag = 0;

    if(rng_init_flag == 0)
    {
        if(sstar_rng_init() == 0)
        {
            return TEE_ERROR_BUSY;
        }
        rng_init_flag=1;
    }

    sstar_rng_read(buf, blen);

    return TEE_SUCCESS;
}

uint8_t hw_get_random_byte(void)
{
    uint16_t rng = 0;
    TEE_Result ret = do_rng_read(&rng,1);
    if(ret == TEE_SUCCESS)
        return rng;
    else
        return ret;
}

TEE_Result crypto_sstar_rng_read(void *buf, size_t blen)
{
    if (!buf)
        return TEE_ERROR_BAD_PARAMETERS;

    return do_rng_read(buf, blen);
}

uint8_t sstar_get_random_byte(void)
{
    //align to 4 bytes to avoid alignment fault before MMU enabled
    uint8_t data __attribute__((aligned(4))) = 0;

    if (do_rng_read(&data, 1))
        return 0;

    return data;
}

