/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <config.h>
#include <kernel/early_ta.h>
#include <kernel/linker.h>
#include <kernel/pseudo_ta.h>
#include <kernel/tee_ta_manager.h>
#include <kernel/thread.h>
#include <string.h>
#include <tee/uuid.h>
#include <user_ta_header.h>
#include <pta_versig.h>
#include <crypto/crypto.h>
#include <utee_defines.h>

#define PTA_NAME "versig.pta"

uint8_t rsa_public_N[] = {
    0xbc, 0xce, 0x1f, 0xc6, 0x27, 0x89, 0xfa, 0x5a,
    0x32, 0x81, 0xff, 0x96, 0xd0, 0x9a, 0x10, 0x20,
    0x96, 0xd1, 0x91, 0xea, 0x9f, 0x59, 0x74, 0xc3,
    0x1e, 0x12, 0x60, 0x4f, 0xc4, 0xba, 0x7d, 0xbc,
    0xa9, 0xa8, 0x01, 0xae, 0x97, 0x32, 0x0f, 0x11,
    0xc3, 0xfa, 0xeb, 0xc0, 0x91, 0xf2, 0xd5, 0xd7,
    0x13, 0x1c, 0xa9, 0x8e, 0x94, 0x3e, 0xc3, 0xce,
    0xa9, 0x96, 0xfd, 0x05, 0xf8, 0xa9, 0xf1, 0x09,
    0xe2, 0x5f, 0x7b, 0xee, 0xdf, 0x75, 0x72, 0x63,
    0x13, 0x11, 0xa5, 0x05, 0x5e, 0xdf, 0xf3, 0x79,
    0x26, 0x9f, 0x0c, 0x9a, 0x71, 0x61, 0x3d, 0x6f,
    0x77, 0xf0, 0x60, 0x3b, 0x48, 0x4c, 0xc0, 0x7e,
    0xcb, 0xb5, 0x54, 0xa3, 0x7d, 0xf5, 0xad, 0xb0,
    0xba, 0x62, 0xef, 0xa1, 0xb0, 0x9f, 0x60, 0x9f,
    0x77, 0xc9, 0x80, 0xe1, 0x4a, 0x37, 0x6b, 0xa6,
    0x71, 0x71, 0xbb, 0x64, 0x22, 0x9c, 0x4a, 0x47,
    0x5c, 0xff, 0xc9, 0x3b, 0x83, 0x3f, 0x6e, 0xe7,
    0x9a, 0x70, 0xc8, 0x07, 0x26, 0x89, 0x06, 0x8e,
    0xb0, 0x85, 0x3f, 0xc4, 0xc7, 0xdf, 0x19, 0xc7,
    0xd9, 0x1b, 0xf7, 0x3d, 0x49, 0x31, 0xf2, 0x60,
    0xd3, 0xa5, 0x9c, 0xca, 0x52, 0xd1, 0xd5, 0x23,
    0x61, 0x57, 0xc0, 0x1b, 0xaa, 0x6c, 0xbc, 0x99,
    0x45, 0x98, 0x16, 0x07, 0x40, 0x99, 0x58, 0x3a,
    0xc9, 0xa5, 0x1f, 0xb6, 0x65, 0x96, 0x17, 0x2f,
    0xc5, 0x6b, 0x44, 0x69, 0x10, 0x9a, 0xd1, 0x23,
    0xff, 0xbc, 0x26, 0x4a, 0x85, 0x48, 0x61, 0xf3,
    0xc4, 0x80, 0x2b, 0xf7, 0xe9, 0xbe, 0xbc, 0x45,
    0xae, 0x5f, 0x12, 0x95, 0xbd, 0xb2, 0x9b, 0x89,
    0x2f, 0x92, 0xd9, 0x2c, 0x29, 0xe4, 0x15, 0xcb,
    0xd1, 0x2e, 0x80, 0xbe, 0x7b, 0x74, 0x91, 0x52,
    0x31, 0xce, 0xc0, 0x34, 0x7a, 0x3f, 0xeb, 0x87,
    0xbe, 0xa3, 0x6d, 0x2c, 0xa9, 0xa2, 0xaa, 0x85,
};

const uint32_t rsa_public_E = 65537;

static TEE_Result do_digest(uint8_t *msg_buf, uint32_t msg_buf_size,
                uint8_t *dig_buf, uint32_t dig_buf_size)
{
    TEE_Result res = TEE_SUCCESS;
    void *ctx = NULL;

    res = crypto_hash_alloc_ctx(&ctx, TEE_ALG_SHA256);
    if (res)
        return res;
    res = crypto_hash_init(ctx);
    if (res)
        goto out;
    res = crypto_hash_update(ctx, msg_buf, msg_buf_size);
    if (res)
        goto out;
    res = crypto_hash_final(ctx, dig_buf, dig_buf_size);
out:
    crypto_hash_free_ctx(ctx);
    return res;
}

static TEE_Result do_verify(uint8_t *dig_buf, uint32_t dig_buf_size,
                uint8_t *sig_buf, uint32_t sig_buf_size)
{
    struct rsa_public_key key;
    TEE_Result res;
    uint32_t e = TEE_U32_TO_BIG_ENDIAN(rsa_public_E);

    res = crypto_acipher_alloc_rsa_public_key(&key,
                          sizeof(rsa_public_N) * 8);
    if (res)
        return TEE_ERROR_SECURITY;

    res = crypto_bignum_bin2bn((uint8_t *)&e, sizeof(e), key.e);
    if (res)
        goto out;
    res = crypto_bignum_bin2bn(rsa_public_N, sizeof(rsa_public_N),
                   key.n);
    if (res)
        goto out;

    res = crypto_acipher_rsassa_verify(TEE_ALG_RSASSA_PKCS1_V1_5_SHA256, &key, TEE_SHA256_HASH_SIZE,
                       dig_buf, dig_buf_size,
                       sig_buf, sig_buf_size);
out:
    crypto_acipher_free_rsa_public_key(&key);
    if (res)
        return TEE_ERROR_SECURITY;
    return TEE_SUCCESS;
}

static TEE_Result verify_signature(uint32_t param_types, TEE_Param params[4])
{
    TEE_Result res = 0;
    uint8_t *msg_buf = NULL;
    uint32_t msg_buf_size = 0;
    uint8_t *dig_buf = NULL;
    uint32_t dig_buf_size = 0;
    uint8_t *sig_buf = NULL;
    uint32_t sig_buf_size = 0;
    uint32_t exp_param_types;

    exp_param_types = TEE_PARAM_TYPES(
        TEE_PARAM_TYPE_MEMREF_INPUT,
        TEE_PARAM_TYPE_MEMREF_INPUT,
        TEE_PARAM_TYPE_NONE,
        TEE_PARAM_TYPE_NONE);

    if (param_types != exp_param_types)
    {
        DMSG("parameter type check failed\n");
        return TEE_ERROR_BAD_PARAMETERS;
    }

    msg_buf_size = params[0].memref.size;
    msg_buf = malloc(msg_buf_size);
    if (!msg_buf)
    {
        DMSG("malloc msg_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    dig_buf_size = TEE_SHA256_HASH_SIZE; //SHA256
    dig_buf = malloc(dig_buf_size);
    if (!dig_buf)
    {
        DMSG("malloc dig_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    memmove(msg_buf, params[0].memref.buffer, msg_buf_size);

    res = do_digest(msg_buf, msg_buf_size, dig_buf, dig_buf_size);
    if (res != TEE_SUCCESS)
        goto exit;

    sig_buf_size = params[1].memref.size;
    sig_buf = malloc(sig_buf_size);
    if (!sig_buf)
    {
        DMSG("malloc sig_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    memmove(sig_buf, params[1].memref.buffer, sig_buf_size);

    res = do_verify(dig_buf, dig_buf_size, sig_buf, sig_buf_size);
    if (res)
        DMSG("verify signature failed\n");
    else
        DMSG("verify signature success\n");

exit:
    if (msg_buf)
        free(msg_buf);

    if (dig_buf)
        free(dig_buf);

    if (sig_buf)
        free(sig_buf);

    return res;
}

static TEE_Result invoke_command(void *pSessionContext __unused,
                uint32_t nCommandID, uint32_t nParamTypes,
                TEE_Param pParams[TEE_NUM_PARAMS])
{
    assert(thread_get_id_may_fail() != THREAD_ID_INVALID);
    assert(thread_is_in_normal_mode());

    switch (nCommandID) {

    case PTA_CMD_VERSIG_VERIFY:
        return verify_signature(nParamTypes, pParams);

    default:
        break;
    }

    return TEE_ERROR_NOT_IMPLEMENTED;
}

pseudo_ta_register(.uuid = PTA_VERSIG_UUID, .name = PTA_NAME,
            .flags = PTA_DEFAULT_FLAGS,
            .invoke_command_entry_point = invoke_command);
