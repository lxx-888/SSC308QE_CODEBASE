/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <config.h>
#include <kernel/early_ta.h>
#include <kernel/linker.h>
#include <kernel/pseudo_ta.h>
#include <kernel/tee_ta_manager.h>
#include <kernel/thread.h>
#include <string.h>
#include <tee/uuid.h>
#include <user_ta_header.h>
#include <otp_ut.h>
#include <pta_otp.h>

#define PTA_NAME "otp.pta"

static TEE_Result invoke_command(void *pSessionContext __unused,
                uint32_t nCommandID, uint32_t nParamTypes,
                TEE_Param pParams[TEE_NUM_PARAMS])
{
#ifndef CFG_ENABLE_UT
    (void)nParamTypes;
    (void)pParams;
#endif

    assert(thread_get_id_may_fail() != THREAD_ID_INVALID);
    assert(thread_is_in_normal_mode());

    switch (nCommandID) {

    case PTA_OTP_READ_CMD:
#ifdef CFG_ENABLE_UT
        return otp_read_ut_pta(nParamTypes, pParams);
#else
        break;
#endif

    case PTA_OTP_WRITE_CMD:
#ifdef CFG_ENABLE_UT
        return otp_write_ut_pta(nParamTypes, pParams);
#else
        break;
#endif

    default:
        break;
    }

    return TEE_ERROR_NOT_IMPLEMENTED;
}

pseudo_ta_register(.uuid = PTA_OTP_UUID, .name = PTA_NAME,
            .flags = PTA_DEFAULT_FLAGS,
            .invoke_command_entry_point = invoke_command);
