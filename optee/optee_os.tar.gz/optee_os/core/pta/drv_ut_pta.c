/* SigmaStar trade secret */
/* Copyright (c) [2022~2023] SigmaStar Technology.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
SigmaStar and be kept in strict confidence
(SigmaStar Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of SigmaStar Confidential
Information is unlawful and strictly prohibited. SigmaStar hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/

#include <config.h>
#include <kernel/early_ta.h>
#include <kernel/linker.h>
#include <kernel/pseudo_ta.h>
#include <kernel/tee_ta_manager.h>
#include <kernel/thread.h>
#include <string.h>
#include <tee/uuid.h>
#include <user_ta_header.h>
#include <pta_drv_ut.h>
#ifdef CFG_DRIVERS_SSTAR_SEM
#include <sem_ut.h>
#endif
#ifdef CFG_DRIVERS_SSTAR_I2C
#include <iic_ut.h>
#endif

#define PTA_NAME "drv_ut.pta"

static TEE_Result invoke_command(void *pSessionContext __unused,
                uint32_t nCommandID, uint32_t nParamTypes,
                TEE_Param pParams[TEE_NUM_PARAMS])
{
    assert(thread_get_id_may_fail() != THREAD_ID_INVALID);
    assert(thread_is_in_normal_mode());

    switch (nCommandID) {

#ifdef CFG_DRIVERS_SSTAR_SEM
    case PTA_CMD_DRV_UT_SEM:
        return sem_ut_pta(nParamTypes, pParams);
#endif

#ifdef CFG_DRIVERS_SSTAR_I2C
    case PTA_CMD_DRV_UT_I2C:
        return i2c_ut_pta(nParamTypes, pParams);
#endif

    default:
        break;
    }

    return TEE_ERROR_NOT_IMPLEMENTED;
}

pseudo_ta_register(.uuid = PTA_DRV_UT_UUID, .name = PTA_NAME,
            .flags = PTA_DEFAULT_FLAGS,
            .invoke_command_entry_point = invoke_command);
