// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2018, Linaro Limited
 */

#ifndef __VERSIG_TA_H__
#define __VERSIG_TA_H__

/* UUID of the versig example trusted application */
#define TA_VERSIG_UUID \
	{ 0xd40f3aff, 0xb23b, 0x4bee, { \
		0x9c, 0x24, 0xdc, 0x7a, 0xa8, 0x05, 0xb3, 0x85 } }

/*
 * in	params[0].tmpref.buffer message buffer
 * in	params[1].tmpref.buffer signature buffer
 */
#define TA_VERSIG_CMD_VERIFY		0

#endif /* __VERSIG_TA_H */
