#include <err.h>
#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the TA's h-file(s)) */
#include <td_ta.h>

#include <td_ca.h>

static TEEC_Context ctx;
static TEEC_Session sess;
static uint32_t eo;
static uint8 metadata[METADATA_SIZE];
static pthread_mutex_t mutex;

static void teec_err(TEEC_Result res, uint32_t eo, const char *str)
{
    errx(1, "%s: %#" PRIx32 " (error origin %#" PRIx32 ")", str, res, eo);
}

static void tdapp_init_metadata(void)
{
#ifdef UNIT_TEST
  int i;
#endif

  memcpy(metadata, "metadata", 8);
  metadata[ 8] = 0x00;
  metadata[ 9] = 0x00;
  metadata[10] = 0x00;
  metadata[11] = 0x00;
#ifdef UNIT_TEST
  metadata[12] = 0x01;
  metadata[13] = 0x00;
  metadata[14] = 0x00;
  metadata[15] = 0x02;
  metadata[16] = 0x00;
  metadata[17] = 0x00;
  metadata[18] = 0x03;
  metadata[19] = 0x00;
  metadata[20] = 0x00;
  metadata[21] = 0x04;
  metadata[22] = 0x00;
  metadata[23] = 0x00;
  for (i = 24; i < METADATA_SIZE; i+=4) {
    memcpy(&metadata[i], &metadata[0], 4);
  }
#endif
}

static void tdapp_update_metadata(uint32 ch, uint16 val)
{
  metadata[ 8] = (ch<<6) | ((val>>8) & 0x3F);
  metadata[ 9] = val&0xFF;
}

void prepare_tee_session(void)
{

    TEEC_UUID uuid = TA_TD_UUID;
    TEEC_Result res;

    res = TEEC_InitializeContext(NULL, &ctx);
    if (res)
        errx(1, "TEEC_InitializeContext(NULL, x): %#" PRIx32, res);

    res = TEEC_OpenSession(&ctx, &sess, &uuid, TEEC_LOGIN_PUBLIC, NULL,
                   NULL, &eo);
    if (res)
        teec_err(res, eo, "TEEC_OpenSession(TEEC_LOGIN_PUBLIC)");
}

void terminate_tee_session(void)
{
    TEEC_CloseSession(&sess);
    TEEC_FinalizeContext(&ctx);
}

TEEC_Result td_ca_initialize(S_TDAPI_INIT *init)
{
    TEEC_Operation op;
    TEEC_Result res;

    pthread_mutex_lock(&mutex);

    memset(&op, 0, sizeof(op));

    op.params[0].tmpref.buffer = init;
    op.params[0].tmpref.size = sizeof(S_TDAPI_INIT);

    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT,
                                    TEEC_NONE,
                                    TEEC_NONE,
                                    TEEC_NONE);

    res = TEEC_InvokeCommand(&sess, TA_TD_CMD_INITIALIZE, &op, &eo);
    if (res)
    {
        teec_err(res, eo, "TEEC_InvokeCommand(TA_TD_CMD_INITIALIZE)");
        goto out;
    }

    tdapp_init_metadata();

out:
    pthread_mutex_unlock(&mutex);

    return res;
}

#ifdef UNIT_TEST
TEEC_Result td_ca_frame_process(uint32 ch, uint8 *p_sei_data)
#else
TEEC_Result td_ca_frame_process(uint32 ch, uint8 *p_sei_data, uint8 *p_slice_start,
                                    uint32 slice_size, uint32 buf_limit, uint32 buf_size)
#endif
{
    TEEC_Operation op;
    TEEC_Result res;

    static uint16_t frame[NUM_CH];
    S_TD_FP_DATA s_fp_data;

    pthread_mutex_lock(&mutex);

#ifdef UNIT_TEST
    s_fp_data.ch = ch;
#else
    s_fp_data.ch = ch;
    s_fp_data.slice_size = slice_size;
    s_fp_data.buf_limit = buf_limit;
    s_fp_data.buf_size = buf_size;
#endif

    tdapp_update_metadata(ch, frame[ch]);

    memset(&op, 0, sizeof(op));

    op.params[0].tmpref.buffer = &s_fp_data;
    op.params[0].tmpref.size = sizeof(S_TD_FP_DATA);
    op.params[1].tmpref.buffer = p_sei_data;
    op.params[1].tmpref.size = SEI_SPACE_SIZE;
    op.params[2].tmpref.buffer = metadata;
    op.params[2].tmpref.size = METADATA_SIZE;
#ifndef UNIT_TEST
    op.params[3].tmpref.buffer = p_slice_start;
    op.params[3].tmpref.size = slice_size;
#endif

#ifdef UNIT_TEST
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_OUTPUT, TEEC_MEMREF_TEMP_INPUT, TEEC_NONE);
#else
    op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_OUTPUT, TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_INPUT);
#endif

    res = TEEC_InvokeCommand(&sess, TA_TD_CMD_FRAME_PROCESS, &op, &eo);
    if (res)
        teec_err(res, eo, "TEEC_InvokeCommand(TA_TD_CMD_FRAME_PROCESS)");

    frame[ch]++;

    pthread_mutex_unlock(&mutex);

    return res;
}
