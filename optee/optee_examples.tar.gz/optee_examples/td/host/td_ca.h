#ifndef TD_CA_H
#define TD_CA_H

#include <err.h>
#include <stdio.h>
#include <string.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* TA API: UUID and command IDs */
#include <td_ta.h>

/* ============================ from td_app.h =============================== */
#define MULTI_STREAM
//#define UNIT_TEST
//#define H265

#define MANUFACTURER_INFO "Sigmastar"
#define SERIAL_INFO       "00000001"

#ifdef UNIT_TEST
#define MODEL_INFO        "UnitTest"
#define SEI_SPACE_SIZE TD_SEI_SIZE_MAX
#define METADATA_SIZE TD_METADATA_SIZE_MAX
#else
#define MODEL_INFO        "IntegrationTest"
#define SEI_SPACE_SIZE (144)
#define METADATA_SIZE (12)
#endif

#ifdef MULTI_STREAM
#define NUM_CH (4)
#else
#define NUM_CH (1)
#endif
/* ========================================================================== */

/* =========================== from td_driver.h ============================= */
typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned long  uint32;

typedef struct _S_TD_TIMESTAMP {
  uint16 year;
  uint8 month;
  uint8 day;
  uint8 hour;
  uint8 minute;
  uint8 second;
  uint8 frame;
} S_TD_TIMESTAMP;

typedef struct _S_TD_FRATE {
  uint8 frame_rate;
  uint16 nume;
  uint16 deno;
} S_TD_FRATE;

#define TD_YEAR_BASE (2020)

#define TD_SEI_GEN        (0x01)
#define TD_TIMESTAMP_INIT (0x02)
#define TD_TIMESTAMP_INC  (0x04)
#define TD_SHA_CALC       (0x08)
#define TD_POS_CALC       (0x10)

#define TD_SEI_SIZE_MAX      (1024)
#define TD_METADATA_SIZE_MAX  (640)
#define TD_INFO_SIZE_MAX       (32)
#define TD_SHA_KEY_MAX         (64)
#define TD_SHA_VAL_SIZE        (32)
#define TD_CDC_INFO_NUM        (16)
#define TD_POS_INFO_NUM        (TD_CDC_INFO_NUM)
#define TD_INDIVIDUAL_ID_SIZE  (32)

#define TD_AUTO_INC   (0x1)
#define TD_MANUAL_INC (0x0)

#define TD_CH0    (0x0)
#define TD_CH1    (0x1)
#define TD_CH2    (0x2)
#define TD_CH3    (0x3)
#define TD_CH_ALL (0x4)

#define TD_INT_NONE (0x0)
#define TD_INT_SEI  (0x1)
#define TD_INT_POS  (0x2)
#define TD_INT_SHA  (0x4)

#define TD_STATUS_BUSY      (0x1)
#define TD_STATUS_SEI_READY (0x2)
#define TD_STATUS_POS_READY (0x4)
#define TD_STATUS_SHA_READY (0x8)
/* ========================================================================== */

/* ============================ from td_api.h =============================== */
typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned long  uint32;

#define TDAPI_MAX_CH (4)

#define TDAPI_MODE_H264 (0)
#define TDAPI_MODE_H265 (1)

typedef struct _S_TDAPI_TIMESTAMP {
  uint16 year;
  uint8 month;
  uint8 day;
  uint8 hour;
  uint8 minute;
  uint8 second;
} S_TDAPI_TIMESTAMP;

typedef struct _S_TDAPI_SLICE_DATA {
  uint8 *start;     // start address of slice data (1 frame)
  uint32 size;      // size of slice data (1 frame)
  uint32 buf_limit; // end address of stream buffer
  uint32 buf_size;  // size of stream buffer
} S_TDAPI_SLICE_DATA;

typedef struct _S_TDAPI_INIT {
  char manufacturer_info[TD_INFO_SIZE_MAX+1];
  char model_info[TD_INFO_SIZE_MAX+1];
  char serial_info[TD_INFO_SIZE_MAX+1];
  uint32 sei_space_size;
  S_TDAPI_TIMESTAMP timestamp;
  double frame_rate[TDAPI_MAX_CH];
  uint32 num_ch;
  uint32 mode;
} S_TDAPI_INIT;
/* ========================================================================== */

/* ========================== from td_middle.h ============================== */
typedef struct _S_TD_INIT {
  char manufacturer_info[TD_INFO_SIZE_MAX+1];
  char model_info[TD_INFO_SIZE_MAX+1];
  char serial_info[TD_INFO_SIZE_MAX+1];
  uint32 sei_space_size;
} S_TD_INIT;

typedef struct _S_TD_INIT_TS {
  S_TD_TIMESTAMP ts;
  double frame_rate;
} S_TD_INIT_TS;
/* ========================================================================== */

typedef struct _S_TD_FP_DATA {
  uint32 ch;
#ifndef UNIT_TEST
  uint32 slice_size;    // size of slice data (1 frame)
  uint32 buf_limit;     // end address of stream buffer
  uint32 buf_size;      // size of stream buffer
#endif
} S_TD_FP_DATA;

#ifdef __cplusplus
extern "C" {
#endif
void prepare_tee_session(void);
void terminate_tee_session(void);
TEEC_Result td_ca_initialize(S_TDAPI_INIT *init);
#ifdef UNIT_TEST
TEEC_Result td_ca_frame_process(uint32 ch, uint8 *p_sei_data);
#else
TEEC_Result td_ca_frame_process(uint32 ch, uint8 *p_sei_data, uint8 *p_slice_start,
                                    uint32 slice_size, uint32 buf_limit, uint32 buf_size);
#endif

#ifdef __cplusplus
}
#endif

#endif /* TD_CA_H */
