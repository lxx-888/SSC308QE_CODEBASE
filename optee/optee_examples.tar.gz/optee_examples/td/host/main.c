// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2018, Linaro Limited
 */

#include <err.h>
#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <td_ca.h>

#ifndef UNIT_TEST
#define FRAME_BUF_SIZE 1024
#define SLICE_SIZE 256
static uint8 frame_buf[FRAME_BUF_SIZE];
static S_TDAPI_SLICE_DATA s_slice_data;
#endif
static uint8 sei_data[SEI_SPACE_SIZE];

int main(int argc, char *argv[])
{
    int i;
    static int fd_ch0, fd_ch1, fd_ch2, fd_ch3;

    int ch;
    S_TDAPI_INIT s_init;
    double frame_rate[4] = {29.97, 27.5, 1.0, 15.2};

    fd_ch0 = open("/mnt/sei_data_ch0.bin", O_WRONLY|O_CREAT|O_APPEND, 0644);
    if (fd_ch0 == -1)
    {
        fprintf(stderr, "open sei_data_ch0.bin failed\n");
        close(fd_ch0);
        goto out;
    }

    fd_ch1 = open("/mnt/sei_data_ch1.bin", O_WRONLY|O_CREAT|O_APPEND, 0644);
    if (fd_ch1 == -1)
    {
        fprintf(stderr, "open sei_data_ch1.bin failed\n");
        close(fd_ch1);
        goto out;
    }

    fd_ch2 = open("/mnt/sei_data_ch2.bin", O_WRONLY|O_CREAT|O_APPEND, 0644);
    if (fd_ch2 == -1)
    {
        fprintf(stderr, "open sei_data_ch2.bin failed\n");
        close(fd_ch2);
        goto out;
    }

    fd_ch3 = open("/mnt/sei_data_ch3.bin", O_WRONLY|O_CREAT|O_APPEND, 0644);
    if (fd_ch3 == -1)
    {
        fprintf(stderr, "open sei_data_ch3.bin failed\n");
        close(fd_ch3);
        goto out;
    }

    // Set initial timestamp
    s_init.timestamp.year = 2024;
    s_init.timestamp.month = 7;
    s_init.timestamp.day = 6;
    s_init.timestamp.hour = 19;
    s_init.timestamp.minute = 21;
    s_init.timestamp.second = 36;

    for (ch = 0; ch < NUM_CH; ch++) {
      // Set frame rate
      s_init.frame_rate[ch] = frame_rate[ch];
    }

    // Set number of channels
    s_init.num_ch = NUM_CH;

    // Set info
    strncpy(s_init.manufacturer_info, MANUFACTURER_INFO, TD_INFO_SIZE_MAX);
    s_init.manufacturer_info[TD_INFO_SIZE_MAX] = '\0';
    strncpy(s_init.model_info, MODEL_INFO, TD_INFO_SIZE_MAX);
    s_init.model_info[TD_INFO_SIZE_MAX] = '\0';
    strncpy(s_init.serial_info, SERIAL_INFO, TD_INFO_SIZE_MAX);
    s_init.serial_info[TD_INFO_SIZE_MAX] = '\0';

    // Set SEI space size
    s_init.sei_space_size = SEI_SPACE_SIZE;

    // Set mode
#ifdef H265
    s_init.mode = TDAPI_MODE_H265;
#else
    s_init.mode = TDAPI_MODE_H264;
#endif

#ifndef UNIT_TEST
    s_slice_data.start = (uint8 *)(&frame_buf[128]);
    s_slice_data.size = SLICE_SIZE;
    s_slice_data.buf_limit = (uint32)(&frame_buf[FRAME_BUF_SIZE]);
    s_slice_data.buf_size = FRAME_BUF_SIZE;
    printf("frame_buf=%p\n", frame_buf);
    printf("start=%p\n", s_slice_data.start);
    printf("size=0x%lx\n", s_slice_data.size);
    printf("buf_limit=0x%lx\n", s_slice_data.buf_limit);
    printf("buf_size=0x%lx\n", s_slice_data.buf_size);
#endif

    prepare_tee_session();

    td_ca_initialize(&s_init);

    printf("start frame process\n");
    for (i = 0; i < 10000; i++)
    {
        if (i % 100 == 0)
            printf("i=%d\n", i);

#ifdef UNIT_TEST
        td_ca_frame_process(TD_CH0, sei_data);
#else
        td_ca_frame_process(TD_CH0, sei_data, s_slice_data.start, s_slice_data.size, s_slice_data.buf_limit, s_slice_data.buf_size);
#endif
        write(fd_ch0, &sei_data, SEI_SPACE_SIZE);

#ifdef UNIT_TEST
        td_ca_frame_process(TD_CH1, sei_data);
#else
        td_ca_frame_process(TD_CH1, sei_data, s_slice_data.start, s_slice_data.size, s_slice_data.buf_limit, s_slice_data.buf_size);
#endif
        write(fd_ch1, &sei_data, SEI_SPACE_SIZE);

#ifdef UNIT_TEST
        td_ca_frame_process(TD_CH2, sei_data);
#else
        td_ca_frame_process(TD_CH2, sei_data, s_slice_data.start, s_slice_data.size, s_slice_data.buf_limit, s_slice_data.buf_size);
#endif
        write(fd_ch2, &sei_data, SEI_SPACE_SIZE);

#ifdef UNIT_TEST
        td_ca_frame_process(TD_CH3, sei_data);
#else
        td_ca_frame_process(TD_CH3, sei_data, s_slice_data.start, s_slice_data.size, s_slice_data.buf_limit, s_slice_data.buf_size);
#endif
        write(fd_ch3, &sei_data, SEI_SPACE_SIZE);
    }
    printf("end frame process\n");

    terminate_tee_session();

out:
    close(fd_ch0);
    close(fd_ch1);
    close(fd_ch2);
    close(fd_ch3);

    return 0;
}
