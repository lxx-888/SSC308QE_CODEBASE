// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2018, Linaro Limited
 */

#include <inttypes.h>

#include <tee_internal_api.h>

#include <td_ta.h>

#define UNUSED(x) (void)(x)

struct versig {
	TEE_ObjectHandle key;
};

uint8_t rsa_public_N[] = {
    0xbc, 0xce, 0x1f, 0xc6, 0x27, 0x89, 0xfa, 0x5a, 0x32, 0x81, 0xff, 0x96, 0xd0, 0x9a, 0x10,
    0x20, 0x96, 0xd1, 0x91, 0xea, 0x9f, 0x59, 0x74, 0xc3, 0x1e, 0x12, 0x60, 0x4f, 0xc4, 0xba,
    0x7d, 0xbc, 0xa9, 0xa8, 0x01, 0xae, 0x97, 0x32, 0x0f, 0x11, 0xc3, 0xfa, 0xeb, 0xc0, 0x91,
    0xf2, 0xd5, 0xd7, 0x13, 0x1c, 0xa9, 0x8e, 0x94, 0x3e, 0xc3, 0xce, 0xa9, 0x96, 0xfd, 0x05,
    0xf8, 0xa9, 0xf1, 0x09, 0xe2, 0x5f, 0x7b, 0xee, 0xdf, 0x75, 0x72, 0x63, 0x13, 0x11, 0xa5,
    0x05, 0x5e, 0xdf, 0xf3, 0x79, 0x26, 0x9f, 0x0c, 0x9a, 0x71, 0x61, 0x3d, 0x6f, 0x77, 0xf0,
    0x60, 0x3b, 0x48, 0x4c, 0xc0, 0x7e, 0xcb, 0xb5, 0x54, 0xa3, 0x7d, 0xf5, 0xad, 0xb0, 0xba,
    0x62, 0xef, 0xa1, 0xb0, 0x9f, 0x60, 0x9f, 0x77, 0xc9, 0x80, 0xe1, 0x4a, 0x37, 0x6b, 0xa6,
    0x71, 0x71, 0xbb, 0x64, 0x22, 0x9c, 0x4a, 0x47, 0x5c, 0xff, 0xc9, 0x3b, 0x83, 0x3f, 0x6e,
    0xe7, 0x9a, 0x70, 0xc8, 0x07, 0x26, 0x89, 0x06, 0x8e, 0xb0, 0x85, 0x3f, 0xc4, 0xc7, 0xdf,
    0x19, 0xc7, 0xd9, 0x1b, 0xf7, 0x3d, 0x49, 0x31, 0xf2, 0x60, 0xd3, 0xa5, 0x9c, 0xca, 0x52,
    0xd1, 0xd5, 0x23, 0x61, 0x57, 0xc0, 0x1b, 0xaa, 0x6c, 0xbc, 0x99, 0x45, 0x98, 0x16, 0x07,
    0x40, 0x99, 0x58, 0x3a, 0xc9, 0xa5, 0x1f, 0xb6, 0x65, 0x96, 0x17, 0x2f, 0xc5, 0x6b, 0x44,
    0x69, 0x10, 0x9a, 0xd1, 0x23, 0xff, 0xbc, 0x26, 0x4a, 0x85, 0x48, 0x61, 0xf3, 0xc4, 0x80,
    0x2b, 0xf7, 0xe9, 0xbe, 0xbc, 0x45, 0xae, 0x5f, 0x12, 0x95, 0xbd, 0xb2, 0x9b, 0x89, 0x2f,
    0x92, 0xd9, 0x2c, 0x29, 0xe4, 0x15, 0xcb, 0xd1, 0x2e, 0x80, 0xbe, 0x7b, 0x74, 0x91, 0x52,
    0x31, 0xce, 0xc0, 0x34, 0x7a, 0x3f, 0xeb, 0x87, 0xbe, 0xa3, 0x6d, 0x2c, 0xa9, 0xa2, 0xaa,
    0x85,
};

uint8_t rsa_public_E[] = {
    0x01, 0x00, 0x01,
};

static TEE_Result do_digest(int8_t *msg_buf, uint32_t msg_buf_size,
                int8_t *dig_buf, uint32_t *dig_buf_size)
{
    TEE_OperationHandle op = TEE_HANDLE_NULL;
    TEE_Result res = 0;

    res = TEE_AllocateOperation(&op, TEE_ALG_SHA256, TEE_MODE_DIGEST, 0);
    if(res != TEE_SUCCESS)
    {
        DMSG("TEE allocate operation failed, res=0x%x", res);
        return res;
    }

    res = TEE_DigestDoFinal(op, msg_buf, msg_buf_size, 
                                dig_buf, dig_buf_size);
    if(res != TEE_SUCCESS)
    {
        DMSG("TEE digest do final failed\n");
        goto exit;
    }
    DMSG("TEE digest do final successful!\n");

exit:
    TEE_FreeOperation(op);
    return res;
}

static TEE_Result do_verify(int8_t *dig_buf, uint32_t dig_buf_size,
                int8_t *sig_buf, uint32_t sig_buf_size)
{
    TEE_Result res;
    TEE_ObjectHandle ob;
    TEE_OperationHandle op = TEE_HANDLE_NULL;
    TEE_Attribute rsaKeyContent[2];

    res = TEE_AllocateOperation(&op,
            TEE_ALG_RSASSA_PKCS1_V1_5_SHA256, TEE_MODE_VERIFY,
            2048);

    if(res != TEE_SUCCESS)
    {
        TEE_FreeOperation(op);
        DMSG("TEE allocate operation failed, res=0x%x\n", res);
        return res;
    }
    else
        DMSG("TEE allocate operation successful!\n");

    res = TEE_AllocateTransientObject(TEE_TYPE_RSA_PUBLIC_KEY, 2048, 
            &ob);
    if(res != TEE_SUCCESS)
    {
        DMSG("TEE allocate transient object failed!\n");
        goto exit;
    }
    else
    {
        DMSG("TEE allocate transient object successful!\n");

        rsaKeyContent[0].attributeID = TEE_ATTR_RSA_MODULUS;
        rsaKeyContent[0].content.ref.buffer = rsa_public_N;
        rsaKeyContent[0].content.ref.length = sizeof(rsa_public_N);

        rsaKeyContent[1].attributeID = TEE_ATTR_RSA_PUBLIC_EXPONENT;
        rsaKeyContent[1].content.ref.buffer = rsa_public_E;
        rsaKeyContent[1].content.ref.length= sizeof(rsa_public_E);
    }

    res = TEE_PopulateTransientObject(ob, rsaKeyContent, 2);
    if(res != TEE_SUCCESS)
    {
        DMSG("TEE populate RSA public key to transient object failed!\n");
        goto exit;
    }
    else
        DMSG("TEE populate RSA public key to transient object successful!\n");

    res = TEE_SetOperationKey(op, ob);
    if(res != TEE_SUCCESS)
    {
        DMSG("TEE set RSA public key object on operaton handle failed!\n");
        goto exit;
    }
    else
        DMSG("TEE set RSA public key object on operaton handle successful!\n");

    res = TEE_AsymmetricVerifyDigest(op, NULL, 0,
        dig_buf, dig_buf_size,
        sig_buf, sig_buf_size);

    if(res != TEE_SUCCESS)
        DMSG("TEE verify digest failed!\n");
    else
        DMSG("TEE verify digest successfully!\n");

exit:
    TEE_FreeOperation(op);
    TEE_FreeTransientObject(ob);

    return res;
}

static TEE_Result verify_signature(void *session, uint32_t param_types, TEE_Param params[4])
{
    TEE_Result res = 0;
    int8_t *msg_buf = NULL;
    uint32_t msg_buf_size = 0;
    int8_t *dig_buf = NULL;
    uint32_t dig_buf_size = 0;
    int8_t *sig_buf = NULL;
    uint32_t sig_buf_size = 0;
    uint32_t exp_param_types;

    UNUSED(session);

    exp_param_types = TEE_PARAM_TYPES(
        TEE_PARAM_TYPE_MEMREF_INPUT,
        TEE_PARAM_TYPE_MEMREF_INPUT,
        TEE_PARAM_TYPE_NONE,
        TEE_PARAM_TYPE_NONE);

    if (param_types != exp_param_types)
    {
        DMSG("parameter type check failed\n");
        return TEE_ERROR_BAD_PARAMETERS;
    }

    msg_buf_size = params[0].memref.size;
    msg_buf = TEE_Malloc(msg_buf_size, 0);
    if (!msg_buf)
    {
        DMSG("malloc msg_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    dig_buf_size = 32; //SHA256
    dig_buf = TEE_Malloc(dig_buf_size, 0);
    if (!dig_buf)
    {
        DMSG("malloc dig_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    TEE_MemMove(msg_buf, params[0].memref.buffer, msg_buf_size);

    res = do_digest(msg_buf, msg_buf_size, dig_buf, &dig_buf_size);
    if (res != TEE_SUCCESS)
        goto exit;

    sig_buf_size = params[1].memref.size;
    sig_buf = TEE_Malloc(sig_buf_size, 0);
    if (!sig_buf)
    {
        DMSG("malloc sig_buf failed");
        res = TEE_ERROR_OUT_OF_MEMORY;
        goto exit;
    }

    TEE_MemMove(sig_buf, params[1].memref.buffer, sig_buf_size);

    res = do_verify(dig_buf, dig_buf_size, sig_buf, sig_buf_size);

exit:
    if (msg_buf)
        TEE_Free(msg_buf);

    if (dig_buf)
        TEE_Free(dig_buf);

    if (sig_buf)
        TEE_Free(sig_buf);

    return res;
}

TEE_Result TA_CreateEntryPoint(void)
{
    /* Nothing to do */
    return TEE_SUCCESS;
}

void TA_DestroyEntryPoint(void)
{
    /* Nothing to do */
}

TEE_Result TA_OpenSessionEntryPoint(uint32_t __unused param_types,
                    TEE_Param __unused params[4],
                    void **session)
{
    struct versig *state;

    /*
     * Allocate and init state for the session.
     */
    state = TEE_Malloc(sizeof(*state), 0);
    if (!state)
        return TEE_ERROR_OUT_OF_MEMORY;

    state->key = TEE_HANDLE_NULL;

    *session = state;

    return TEE_SUCCESS;
}

void TA_CloseSessionEntryPoint(void *session)
{
    struct versig *state = session;

    TEE_FreeTransientObject(state->key);
    TEE_Free(state);
}

TEE_Result TA_InvokeCommandEntryPoint(void *session, uint32_t cmd,
                      uint32_t param_types,
                      TEE_Param params[TEE_NUM_PARAMS])
{
    switch (cmd) {
    case TA_VERSIG_CMD_VERIFY:
        DMSG("TA_VERSIG_CMD_VERIFY\n");
        return verify_signature(session, param_types, params);
    default:
        EMSG("Command ID %#" PRIx32 " is not supported", cmd);
        return TEE_ERROR_NOT_SUPPORTED;
    }
}
