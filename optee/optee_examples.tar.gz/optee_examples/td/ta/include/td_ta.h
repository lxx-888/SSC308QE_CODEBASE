// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2018, Linaro Limited
 */

#ifndef __VERSIG_TA_H__
#define __VERSIG_TA_H__

/* UUID of the versig example trusted application */
#define TA_TD_UUID \
	{ 0x75cbfc99, 0x9814, 0x48f7, { \
		0x8c, 0x52, 0x79, 0x82, 0xbc, 0x13, 0x25, 0xec } }

/*
 * in	params[0].tmpref.buffer message buffer
 * in	params[1].tmpref.buffer signature buffer
 */
#define TA_TD_CMD_INITIALIZE		0
#define TA_TD_CMD_FRAME_PROCESS	1

#endif /* __VERSIG_TA_H */
