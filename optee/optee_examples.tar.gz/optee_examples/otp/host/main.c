/*
 * Copyright (c) 2017, Linaro Limited
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <err.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <limits.h>
#include <stdlib.h>

/* OP-TEE TEE client API (built by optee_client) */
#include <tee_client_api.h>

/* For the UUID (found in the PTA's h-file(s)) */
#include "otp_ut.h"

#define CMD_OFFSET      24
#define OFFSET_ERR_CODE 0x0
#define OFFSET_DATA_SZ  0x2
#define OFFSET_DATA     0x4

#define DBUG_LOG_R_8(buf, _off)  (*(volatile unsigned char *)(buf + _off))
#define DBUG_LOG_R_16(buf, _off) (*(volatile unsigned short *)(buf + _off))
#define DBUG_LOG_W_16(buf, _off, _val)                                                                     \
    {                                                                                                 \
        (*((volatile unsigned short *)(buf + _off))) = (unsigned short)(_val); \
    }

#define OTP_READ_MAX_LEN  (1024+64)

/* TEE resources */
struct test_ctx {
	TEEC_Context ctx;
	TEEC_Session sess;
};

void prepare_tee_session(struct test_ctx *ctx)
{
	TEEC_UUID uuid = TA_OTP_UUID;
	uint32_t origin;
	TEEC_Result res;

	/* Initialize a context connecting us to the TEE */
	res = TEEC_InitializeContext(NULL, &ctx->ctx);
	if (res != TEEC_SUCCESS)
		errx(1, "TEEC_InitializeContext failed with code 0x%x", res);

	/* Open a session with the TA */
	res = TEEC_OpenSession(&ctx->ctx, &ctx->sess, &uuid,
			       TEEC_LOGIN_PUBLIC, NULL, NULL, &origin);
	if (res != TEEC_SUCCESS)
		errx(1, "TEEC_Opensession failed with code 0x%x origin 0x%x",
			res, origin);
}

void terminate_tee_session(struct test_ctx *ctx)
{
	TEEC_CloseSession(&ctx->sess);
	TEEC_FinalizeContext(&ctx->ctx);
}

void otp_show_results(unsigned long op , char * buf)
{
    int err_code = DBUG_LOG_R_16(buf, OFFSET_ERR_CODE);

    if (err_code)
    {
        printf("[ERR] otp control failure, error code:%x\n", err_code);
        return;
    }

    if (op == 0x2)
    {
        int           i, j, k;
        unsigned long size = DBUG_LOG_R_16(buf, OFFSET_DATA_SZ);

        if (size <= 0)
            return;

        printf("Results: \n\r");

        for (i = 0; i < size; i += 16)
        {
            k = (size - i) > 16 ? 16 : (size - i);
            printf("0x%02x:: ", i);
            for (j = i; j < i + k; j++)
            {
                printf("0x%02x ", DBUG_LOG_R_8(buf, j + OFFSET_DATA));
            }

            printf("\n\r");
        }

        DBUG_LOG_W_16(buf, OFFSET_DATA_SZ, 0);
    }
}

void otp_ctrl_W(struct test_ctx *ctx, unsigned long otp_cmd, unsigned long val)
{
	TEEC_Operation op;
	uint32_t origin;
	TEEC_Result res;
	char result[64];

	memset(&op, 0, sizeof(op));
	memset(&result, 0, sizeof(result));
	op.paramTypes = TEEC_PARAM_TYPES(TEEC_VALUE_INPUT,
					 TEEC_VALUE_INPUT,
					 TEEC_MEMREF_TEMP_INOUT,
					 TEEC_NONE);

	op.params[0].value.a = otp_cmd;
	op.params[1].value.a = val;
	op.params[2].tmpref.buffer = result;
	op.params[2].tmpref.size = sizeof(result);


	res = TEEC_InvokeCommand(&ctx->sess, TA_OTP_WRITE_CMD,
				 &op, &origin);
	if (res != TEEC_SUCCESS)
		errx(1, "TEEC_InvokeCommand(TA_OTP_WRITE_CMD) failed 0x%x origin 0x%x",
			res, origin);

    otp_show_results(0x1, result);
}

void otp_ctrl_R(struct test_ctx *ctx, unsigned long otp_cmd)
{
	TEEC_Operation op;
	uint32_t origin;
	TEEC_Result res;
	char readbuf[OTP_READ_MAX_LEN];

	memset(&op, 0, sizeof(op));
	memset(&readbuf, 0, sizeof(readbuf));

	op.paramTypes = TEEC_PARAM_TYPES(TEEC_VALUE_INPUT,
					 TEEC_MEMREF_TEMP_INOUT,
					 TEEC_NONE,
					 TEEC_NONE);

	op.params[0].value.a = otp_cmd;
	op.params[1].tmpref.buffer = readbuf;
    op.params[1].tmpref.size = OTP_READ_MAX_LEN;

	res = TEEC_InvokeCommand(&ctx->sess, TA_OTP_READ_CMD,
				 &op, &origin);
	if (res != TEEC_SUCCESS)
		errx(1, "TEEC_InvokeCommand(TA_OTP_READ_CMD) failed 0x%x origin 0x%x",
			res, origin);

    otp_show_results(0x2, readbuf);
}

int main(int argc, char *argv[])
{
	struct test_ctx ctx;
    unsigned long cmd = 0;
    unsigned long off = 0;
    unsigned long val = 0;

    if (argc < 3) {
            warnx("Unexpected number of arguments %d (expected 3|4)",
                  argc - 1);
            return -1;
    }

	prepare_tee_session(&ctx);

    if ((!strncmp(argv[1], "-w", strlen("-w"))))
    {
        if (argc < 5)
        {
            warnx("Unexpected number of arguments %d (expected 3|4)",
                  argc - 1);
            return -1;
        }

        cmd = (unsigned int)strtoul(argv[2], NULL, 16);
        if (cmd >= 0x100)
        {
            warnx("[ERR] otp cmd 0x%lx out of range 0~0xFF\n", cmd);
            return -1;
        }

        off = (unsigned int)strtoul(argv[3], NULL, 16);
        val = (unsigned int)strtoul(argv[4], NULL, 16);
        otp_ctrl_W(&ctx, (cmd << CMD_OFFSET | off), val);
    }
    else if ((!strncmp(argv[1], "-r", strlen("-r"))))
    {
        cmd = (unsigned int)strtoul(argv[2], NULL, 16);
        if (cmd >= 0x100)
        {
            warnx("[ERR] otp cmd 0x%lx out of range 0~0xFF\n", cmd);
            return -1;
        }

        off = 0;
        otp_ctrl_R(&ctx, (cmd << CMD_OFFSET | off));
    }

	terminate_tee_session(&ctx);
	return 0;
}
